package com.golemslegendarios.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class GolemRenderState extends LivingEntityRenderState {
  /** Progreso 0..1 de la animacion de habilidad, o -1 si no hay habilidad en curso. */
  public float ability = -1.0F;
}
