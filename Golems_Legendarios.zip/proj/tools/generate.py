# -*- coding: utf-8 -*-
"""Genera Java (GolemDefs, FamilyModels), texturas PNG, modelos/items JSON, recetas, loot, tags y lang.
Uso:  python3 tools/generate.py   (desde la raiz del proyecto; requiere Pillow)"""
import json, os, random, sys
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from golem_table import G, FAMILY_SIZE
import models_def as M

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NS = "golemslegendarios"
PKG = "com/golemslegendarios"
ASSETS = f"{ROOT}/src/main/resources/assets/{NS}"
DATA = f"{ROOT}/src/main/resources/data/{NS}"
JAVA = f"{ROOT}/src/main/java/{PKG}"

def w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f: f.write(text)
def wj(path, obj): w(path, json.dumps(obj, ensure_ascii=False, indent=2) + "\n")
def rgb(h): h = h.lstrip("#"); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
def clamp(v): return max(0, min(255, int(v)))
def scale(c, f): return tuple(clamp(x * f) for x in c)
def ramp(hexc): c = rgb(hexc); return [scale(c, f) for f in (0.5, 0.74, 1.0, 1.2, 1.42)]
def glow_ramp(hexc): c = rgb(hexc); return [scale(c, f) for f in (0.55, 0.8, 1.0, 1.12, 1.3)]

# ------------------------------------------------------------------ pintado
def face_idx(wd, ht, style, rng):
    a = [[2] * wd for _ in range(ht)]
    cols = [rng.choice([1, 2, 2, 3]) for _ in range(wd)]
    rows = [rng.choice([1, 2, 2, 3]) for _ in range(ht)]
    for y in range(ht):
        for x in range(wd):
            if style == "crystal":
                v = ((x + y) // 3 + rng.choice([0, 0, 1])) % 4 + 1
            elif style == "wood":
                v = cols[x] + (rng.choice([-1, 0, 0, 0, 1]) if rng.random() < 0.3 else 0)
            elif style == "sand":
                v = rows[y] + (rng.choice([-1, 0, 0, 1]) if rng.random() < 0.3 else 0)
            elif style == "metal":
                if x and rng.random() < 0.8: v = a[y][x-1]
                else: v = rng.choice([1, 2, 2, 2, 3])
            else:
                r = rng.random()
                if x and r < 0.45: v = a[y][x-1]
                elif y and r < 0.75: v = a[y-1][x]
                else: v = rng.choices([0, 1, 2, 3, 4], [1, 3, 4, 3, 1])[0]
            a[y][x] = max(0, min(4, v))
    return a

def paint_rect(img, rect, pal, style, rng, shade=0, border=False, vein=0.0, glowc=None):
    x0, y0, wd, ht = rect
    if wd <= 0 or ht <= 0: return
    idx = face_idx(wd, ht, style, rng)
    for y in range(ht):
        for x in range(wd):
            v = max(0, min(4, idx[y][x] + shade))
            if border and (x in (0, wd-1) or y in (0, ht-1)): v = max(0, v - 1)
            img.putpixel((x0 + x, y0 + y), pal[v] + (255,))
    if vein > 0 and glowc is not None:
        for _ in range(1 + (wd * ht > 120)):
            if rng.random() < min(1.0, vein * 1.3):
                x, y = rng.randrange(wd), rng.randrange(ht)
                for _s in range(rng.randrange(5, 13)):
                    img.putpixel((x0 + x, y0 + y), glowc[rng.choice([2, 3, 3])] + (255,))
                    if rng.random() < 0.5: x += rng.choice([-1, 1])
                    else: y += rng.choice([0, 1])
                    if not (0 <= x < wd and 0 <= y < ht): break

def faces(u, v, wd, ht, d):
    return {"top": (u + d, v, wd, d), "bottom": (u + d + wd, v, wd, d), "right": (u, v + d, d, ht),
            "front": (u + d, v + d, wd, ht), "left": (u + d + wd, v + d, d, ht), "back": (u + 2*d + wd, v + d, wd, ht)}

def paint_entity(e):
    fam = e["family"]
    rng = random.Random(hash(e["id"]) & 0xFFFF if False else sum(map(ord, e["id"])) * 7919)
    base, alt, glow = ramp(e["base"]), ramp(e["alt"]), glow_ramp(e["glow"])
    eye = rgb(e["eye"])
    img = Image.new("RGBA", (M.TEX, M.TEX), (0, 0, 0, 0))
    parts, packed, _ = M.layout(fam)
    for pname, b, u, v in packed:
        x, y, z, wd, ht, d, tag = b
        wd, ht, d = int(wd), int(ht), int(d)
        use_alt = tag in ("crystal", "leaf") or (tag == "horn" and fam != "vegetal")
        pal, style, vein, border = base, e["style"], e["vein"], False
        if tag == "plate": pal = [base[1], base[2], base[3], base[3], base[4]]; border = True
        if use_alt: pal = alt; style = "crystal" if tag == "crystal" else ("stone" if tag == "leaf" else e["style"]); vein = 0
        if tag == "glow": pal = glow; style = "stone"; vein = 0
        if tag == "nose": pal = [base[0], base[1], base[1], base[2], base[2]]
        if e["style"] == "metal" and tag in ("body", "limb", "head"): border = True
        for fname, rect in faces(u, v, wd, ht, d).items():
            sh = {"top": 1, "bottom": -1, "back": -1}.get(fname, 0)
            paint_rect(img, rect, pal, style, rng, sh, border, vein, glow)
        if tag == "head":
            fx, fy, fw, fh = faces(u, v, wd, ht, d)["front"]
            ey = fy + max(1, fh // 2 - 1)
            for ex in (fx + 1, fx + fw - 3):
                for dx in (0, 1):
                    for dy in (0, 1): img.putpixel((ex + dx, ey + dy), eye + (255,))
                for dx in (0, 1): img.putpixel((ex + dx, ey + 2), scale(eye, 0.5) + (255,))
    os.makedirs(f"{ASSETS}/textures/entity", exist_ok=True)
    img.save(f"{ASSETS}/textures/entity/{e['id']}.png")

def paint_armor(e):
    rng = random.Random(sum(map(ord, e["key"])) * 104729)
    base, alt, glow = ramp(e["base"]), ramp(e["alt"]), glow_ramp(e["glow"])
    for layer, name in (("humanoid", "layer1"), ("humanoid_leggings", "layer2")):
        img = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
        for by in range(0, 32, 8):
            for bx in range(0, 64, 8):
                pal = base if (bx // 8 + by // 8) % 3 else [alt[1], alt[2], alt[2], alt[3], alt[3]]
                paint_rect(img, (bx, by, 8, 8), pal, e["style"], rng, 0, e["style"] == "metal", e["vein"] * 0.6, glow)
        d = f"{ASSETS}/textures/entity/equipment/{layer}"
        os.makedirs(d, exist_ok=True)
        img.save(f"{d}/{e['key']}.png")

# ------------------------------------------------------------------ iconos 16x16
def outline(img, col):
    px = img.load(); pts = []
    for y in range(16):
        for x in range(16):
            if px[x, y][3] == 0:
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < 16 and 0 <= ny < 16 and px[nx, ny][3] == 255 and (dx or dy): pts.append((x, y)); break
                    else: continue
                    break
    for p in pts: img.putpixel(p, col + (255,))

def icon_from_rows(rows, pal, e):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    n = len(rows)
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch == "X":
                t = y / max(1, n - 1)
                col = pal[3] if t < 0.25 else pal[2] if t < 0.6 else pal[1]
                if x in (0, 15) or (x > 0 and row[x-1] == "." ): col = pal[3] if t < 0.6 else col
                img.putpixel((x, 2 + y), col + (255,))
    return img

ROWS = {
 "helmet": ["................","....XXXXXXXX....","...XXXXXXXXXX...","...XXXXXXXXXX...","...XXXXXXXXXX...","...XXXXXXXXXX...","...XXX....XXX...","...XXX....XXX..."],
 "chestplate": ["..XXX......XXX..",".XXXXX....XXXXX.","XXXXXXXXXXXXXXXX","XXXXXXXXXXXXXXXX","XXX.XXXXXXXX.XXX","XXX.XXXXXXXX.XXX",".XX.XXXXXXXX.XX.","....XXXXXXXX....","....XXXXXXXX...."],
 "leggings": ["..XXXXXXXXXXXX..","..XXXXXXXXXXXX..","..XXXXXXXXXXXX..","..XXXXX..XXXXX..","..XXXX....XXXX..","..XXXX....XXXX..","..XXXX....XXXX..","..XXXX....XXXX..","..XXXX....XXXX.."],
 "boots": ["................","................","..XXXX....XXXX..","..XXXX....XXXX..","..XXXX....XXXX..",".XXXXX....XXXXX.","XXXXXX....XXXXXX","XXXXXX....XXXXXX"],
}

def draw_item(kind, e):
    pal = ramp(e["base"]); alt = ramp(e["alt"]); glow = glow_ramp(e["glow"])
    wood = (110, 80, 45)
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    if kind in ROWS:
        img = icon_from_rows(ROWS[kind], [alt[0], pal[1], pal[2], alt[3]] if False else [pal[0], pal[1], pal[2], alt[3]], e)
        for y in range(3, 12, 3):
            for x in range(16):
                if img.getpixel((x, y))[3] and (x * 7 + y * 3) % 5 == 0: img.putpixel((x, y), glow[2] + (255,))
    elif kind == "sword":
        for i in range(10):
            img.putpixel((5 + i, 10 - i), pal[2] + (255,)); img.putpixel((6 + i, 10 - i), alt[3] + (255,))
        for i in range(3): img.putpixel((4 + i, 11 - i + 1), wood + (255,)); 
        img.putpixel((3, 13), wood + (255,)); img.putpixel((2, 14), wood + (255,))
        for p in ((4, 9), (5, 9), (6, 11), (6, 12), (4, 10)): img.putpixel(p, scale(glow[1], 1.0) + (255,))
        img.putpixel((7, 8), glow[3] + (255,))
    elif kind == "pickaxe":
        for i in range(10): img.putpixel((3 + i, 13 - i), wood + (255,))
        for (x, y) in [(4,5),(5,4),(6,3),(7,3),(8,3),(9,3),(10,3),(11,4),(12,5),(13,6),(6,4),(7,4),(8,4),(9,4),(10,4),(11,5)]:
            img.putpixel((x, y), (alt[3] if y == 3 else pal[2]) + (255,))
        img.putpixel((8, 4), glow[3] + (255,))
    elif kind == "shard":
        for (x, y) in [(7,2),(8,2),(6,3),(7,3),(8,3),(9,3),(5,4),(6,4),(7,4),(8,4),(9,4),(10,4),(5,5),(6,5),(7,5),(8,5),(9,5),(10,5),(6,6),(7,6),(8,6),(9,6),(6,7),(7,7),(8,7),(9,7),(7,8),(8,8),(7,9),(8,9),(7,10)]:
            img.putpixel((x, y + 2), (alt[3] if x < 8 else pal[3]) + (255,))
        for (x, y) in [(7,5),(8,6),(7,7)]: img.putpixel((x, y + 2), glow[3] + (255,))
    elif kind == "core":
        for y in range(3, 13):
            for x in range(3, 13):
                t = (x + y) % 3
                img.putpixel((x, y), (pal[1] if t == 0 else pal[2] if t == 1 else pal[3]) + (255,))
        for y in range(6, 10):
            for x in range(6, 10): img.putpixel((x, y), glow[3 if (x + y) % 2 else 2] + (255,))
    outline(img, pal[0])
    return img

def draw_egg(e):
    p, s = rgb(e["base"]), rgb(e["alt"])
    p = scale(p, 1.35) if sum(p) < 200 else p
    if sum(s) < 150: s = scale(s, 1.6)
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    rng = random.Random(sum(map(ord, e["id"])))
    for y in range(16):
        for x in range(16):
            ex = (x - 7.5) / (4.6 + (y - 2) * 0.12 if y < 8 else 5.6); ey = (y - 8.5) / 6.6
            if ex * ex + ey * ey <= 1.0: img.putpixel((x, y), p + (255,))
    for _ in range(14):
        x, y = rng.randrange(16), rng.randrange(16)
        if img.getpixel((x, y))[3]:
            img.putpixel((x, y), s + (255,))
            if x < 15 and img.getpixel((x + 1, y))[3] and rng.random() < 0.6: img.putpixel((x + 1, y), s + (255,))
    outline(img, scale(p, 0.45))
    return img

# ------------------------------------------------------------------ Java generado
def jstr(s): return '"' + s.replace('"', '\\"') + '"'
def jf(v): return repr(float(v)) + "f"
def jd(v): return repr(float(v))

def gen_defs():
    lines = []
    for e in G:
        w_, h_ = FAMILY_SIZE[e["family"]]
        ab = ",\n".join(
            f'      new GolemDef.AbilitySpec(Ability.{a["kind"]}, {a["cd"]}, {jf(a["power"])}, {jd(a["range"])}, {jstr(a["particle"])}, {jstr(a["effect"])}, {a["et"]}, {a["ea"]}, {jstr(a["extra"])})'
            for a in e["abil"])
        hit = e["hit"]
        lines.append(f'''    new GolemDef({jstr(e["id"])}, {jstr(e["key"])}, {jstr(e["family"])}, {jstr(e["block"])}, {jd(e["hp"])}, {jd(e["dmg"])}, {jd(e["spd"])}, {jd(e["armor"])}, {jd(e["kb"])}, {jf(w_)}, {jf(h_)}, {str(e["fire"]).lower()}, {str(e["water"]).lower()}, {e["regen"][0]}, {jf(e["regen"][1])}, {e["tier"]}, {jstr(hit[0])}, {hit[1]}, {hit[2]}, new GolemDef.AbilitySpec[] {{
{ab}
    }})''')
    src = f'''package com.golemslegendarios.entity;

// ARCHIVO GENERADO por tools/generate.py a partir de tools/golem_table.py. No editar a mano.
public final class GolemDefs {{
  private GolemDefs() {{}}

  public static final GolemDef[] ALL = new GolemDef[] {{
{(","+chr(10)).join(lines)}
  }};
}}
'''
    w(f"{JAVA}/entity/GolemDefs.java", src)

def f2(v): return repr(float(v)) + "f"
def gen_models():
    out = ['''package com.golemslegendarios.client;

import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;

// ARCHIVO GENERADO por tools/generate.py (anatomia en tools/models_def.py). No editar a mano.
public final class FamilyModels {
  private FamilyModels() {}

  public static LayerDefinition create(String family) {
    MeshDefinition mesh = new MeshDefinition();
    PartDefinition root = mesh.getRoot();
    switch (family) {''']
    for fam in M.FAMILIES:
        parts, _, an = M.layout(fam)
        out.append(f'      case "{fam}" -> {{')
        for pname in ("head", "body", "right_arm", "left_arm", "right_leg", "left_leg"):
            p = parts[pname]
            cb = "CubeListBuilder.create()" + (".mirror()" if p["mirror"] else "")
            for (x, y, z, wd, ht, d, tag, u, v) in p["boxes"]:
                cb += f".texOffs({u}, {v}).addBox({f2(x)}, {f2(y)}, {f2(z)}, {f2(wd)}, {f2(ht)}, {f2(d)})"
            px, py, pz = p["pose"]
            out.append(f'        root.addOrReplaceChild("{pname}", {cb}, PartPose.offset({f2(px)}, {f2(py)}, {f2(pz)}));')
        out.append("      }")
    out.append('''      default -> throw new IllegalArgumentException("Familia desconocida: " + family);
    }
    return LayerDefinition.create(mesh, 128, 128);
  }

  /** Parametros de animacion por familia: {amplitud piernas, amplitud brazos, flotacion}. */
  public static float[] anim(String family) {
    return switch (family) {''')
    for fam in M.FAMILIES:
        a = M.FAMILIES[fam]["anim"]
        out.append(f'      case "{fam}" -> new float[] {{{f2(a["leg"])}, {f2(a["arm"])}, {f2(a["bob"])}}};')
    out.append('''      default -> new float[] {1.0f, 0.7f, 0.0f};
    };
  }
}
''')
    w(f"{JAVA}/client/FamilyModels.java", "\n".join(out))

# ------------------------------------------------------------------ assets / data
PIECES = ["shard", "core", "sword", "pickaxe", "helmet", "chestplate", "leggings", "boots"]
ES_NAME = {"shard": "Fragmento de {m}", "core": "Núcleo de {m}", "sword": "Espada de {m} Legendaria", "pickaxe": "Pico de {m} Legendario",
           "helmet": "Casco de {m} Legendario", "chestplate": "Peto de {m} Legendario", "leggings": "Pantalones de {m} Legendarios", "boots": "Botas de {m} Legendarias"}
EN_NAME = {"shard": "{m} Shard", "core": "{m} Core", "sword": "Legendary {m} Sword", "pickaxe": "Legendary {m} Pickaxe",
           "helmet": "Legendary {m} Helmet", "chestplate": "Legendary {m} Chestplate", "leggings": "Legendary {m} Leggings", "boots": "Legendary {m} Boots"}

def item_files(item_id, handheld=False):
    wj(f"{ASSETS}/items/{item_id}.json", {"model": {"type": "minecraft:model", "model": f"{NS}:item/{item_id}"}})
    wj(f"{ASSETS}/models/item/{item_id}.json", {"parent": "minecraft:item/handheld" if handheld else "minecraft:item/generated",
                                                 "textures": {"layer0": f"{NS}:item/{item_id}"}})

def recipe(rid, pattern, key, result):
    wj(f"{DATA}/recipe/{rid}.json", {"type": "minecraft:crafting_shaped", "category": "equipment", "pattern": pattern, "key": key,
                                      "result": {"id": f"{NS}:{result}", "count": 1}})

def main():
    es, en = {}, {}
    for e in G:
        k = e["key"]
        paint_entity(e); paint_armor(e)
        os.makedirs(f"{ASSETS}/textures/item", exist_ok=True)
        for p in PIECES:
            draw_item(p, e).save(f"{ASSETS}/textures/item/{k}_{p}.png")
            item_files(f"{k}_{p}", handheld=p in ("sword", "pickaxe"))
            es[f"item.{NS}.{k}_{p}"] = ES_NAME[p].format(m=e["es"]); en[f"item.{NS}.{k}_{p}"] = EN_NAME[p].format(m=e["en"])
        egg = f"{e['id']}_spawn_egg"
        draw_egg(e).save(f"{ASSETS}/textures/item/{egg}.png"); item_files(egg)
        es[f"item.{NS}.{egg}"] = "Huevo generador de " + e["name_es"]; en[f"item.{NS}.{egg}"] = e["name_en"] + " Spawn Egg"
        es[f"entity.{NS}.{e['id']}"] = e["name_es"]; en[f"entity.{NS}.{e['id']}"] = e["name_en"]
        wj(f"{ASSETS}/equipment/{k}.json", {"layers": {"humanoid": [{"texture": f"{NS}:{k}"}], "humanoid_leggings": [{"texture": f"{NS}:{k}"}]}})
        wj(f"{DATA}/tags/item/repair/{k}.json", {"values": [f"{NS}:{k}_shard", f"{NS}:{k}_core"]})
        S = {"S": f"{NS}:{k}_shard", "T": "minecraft:stick", "C": f"{NS}:{k}_core"}
        recipe(f"{k}_sword", ["S", "S", "T"], {x: S[x] for x in "ST"}, f"{k}_sword")
        recipe(f"{k}_pickaxe", ["SSS", " T ", " T "], {x: S[x] for x in "ST"}, f"{k}_pickaxe")
        recipe(f"{k}_helmet", ["SSS", "S S"], {"S": S["S"]}, f"{k}_helmet")
        recipe(f"{k}_chestplate", ["S S", "SCS", "SSS"], {x: S[x] for x in "SC"}, f"{k}_chestplate")
        recipe(f"{k}_leggings", ["SSS", "S S", "S S"], {"S": S["S"]}, f"{k}_leggings")
        recipe(f"{k}_boots", ["S S", "S S"], {"S": S["S"]}, f"{k}_boots")
        pools = [
            {"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{NS}:{k}_core"}]},
            {"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{NS}:{k}_shard",
                                       "functions": [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": 4, "max": 8}}]}]},
        ]
        for (item, lo, hi) in e["drops"]:
            pools.append({"rolls": 1, "entries": [{"type": "minecraft:item", "name": item,
                          "functions": [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}]}]})
        wj(f"{DATA}/loot_table/entities/{e['id']}.json", {"type": "minecraft:entity", "pools": pools})
    es[f"itemGroup.{NS}"] = "Gólems Legendarios"; en[f"itemGroup.{NS}"] = "Legendary Golems"
    for loc in ("es_es", "es_mx", "es_ar", "es_cl", "es_ec", "es_uy", "es_ve"): wj(f"{ASSETS}/lang/{loc}.json", es)
    wj(f"{ASSETS}/lang/en_us.json", en)
    # icono del mod: cabezas de los 5 elementales
    icon = Image.new("RGBA", (128, 128), (24, 26, 32, 255))
    for i, e in enumerate(G[:5]):
        tex = Image.open(f"{ASSETS}/textures/entity/{e['id']}.png")
        _, packed, _ = M.layout(e["family"]); (_, b, u, v) = packed[0]
        wd, ht, d = int(b[3]), int(b[4]), int(b[5])
        head = tex.crop((u + d, v + d, u + d + wd, v + d + ht)).resize((24, 24), Image.NEAREST)
        icon.paste(head, (4 + i * 25, 52))
    icon.save(f"{ASSETS}/icon.png")
    gen_defs(); gen_models()
    print("OK:", len(G), "golems")

if __name__ == "__main__":
    main()
