package com.golemslegendarios.client;

import com.golemslegendarios.GolemsLegendarios;
import com.golemslegendarios.entity.GolemDef;
import com.golemslegendarios.entity.GolemEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class GolemRenderer extends MobRenderer<GolemEntity, GolemRenderState, GolemModel> {
  private final Identifier texture;

  public GolemRenderer(EntityRendererProvider.Context ctx, GolemDef def) {
    super(ctx, new GolemModel(ctx.bakeLayer(GolemsLegendariosClient.layer(def.family())), def.family()), def.width() * 0.55F);
    this.texture = Identifier.fromNamespaceAndPath(GolemsLegendarios.MOD_ID, "textures/entity/" + def.id() + ".png");
  }

  @Override
  public GolemRenderState createRenderState() { return new GolemRenderState(); }

  @Override
  public Identifier getTextureLocation(GolemRenderState state) { return texture; }

  @Override
  public void extractRenderState(GolemEntity entity, GolemRenderState state, float partialTick) {
    super.extractRenderState(entity, state, partialTick);
    float p = (entity.tickCount + partialTick - entity.abilityStart()) / 20.0F;
    state.ability = (p >= 0.0F && p <= 1.0F) ? Mth.clamp(p, 0.0F, 1.0F) : -1.0F;
  }
}
