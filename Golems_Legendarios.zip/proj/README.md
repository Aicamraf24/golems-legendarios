# Gólems Legendarios (Fabric, Minecraft Java 26.1.2)

21 gólems: 5 elementales, 5 de materiales especiales y 11 minerales (uno por material, sin duplicar variantes de pizarra profunda).

## Compilar
- Requiere **JDK 25**.
- **GitHub Actions** (`.github/workflows/build.yml`): sube el proyecto y el `.jar` queda como artefacto `golems-legendarios`.
- **Gradle Wrapper:** `gradle/wrapper/gradle-wrapper.properties` está incluido, pero **`gradle-wrapper.jar` y los scripts `gradlew` no pudieron generarse sin conexión**. El workflow los genera solo (`gradle wrapper`). En local: `gradle wrapper --gradle-version 9.3.0` una vez, luego `./gradlew build`.
- Versiones en `gradle.properties` (Loom 1.15.2, Loader 0.19.3, Fabric API 0.155.0+26.1.2). Si alguna no existe, cámbiala ahí.

## Invocación
Estructura en T como el gólem de hierro: columna de 2 bloques, un bloque a cada lado del segundo y la **calabaza tallada al final**. Funciona en supervivencia y creativo. Un mixin en `CarvedPumpkinBlock#onPlace` revisa las estructuras del mod **antes** que la lógica vanilla (necesario para hierro y cobre).

| Gólem | id | Familia | Bloque | Habilidades |
|---|---|---|---|---|
| Gólem de Fuego | `fire_golem` | horned | `magma_block` | BOLT, PULSE |
| Gólem de Hielo | `ice_golem` | crystal | `packed_ice` | BOLT, PULSE |
| Gólem Eléctrico | `electric_golem` | horned | `waxed_copper_block` | BOLT, CHAIN |
| Gólem de Roca | `rock_golem` | brute | `stone` | SLAM, GUARD |
| Gólem de Naturaleza | `nature_golem` | vegetal | `moss_block` | ROOTS, BARRIER, HEAL |
| Gólem de Obsidiana | `obsidian_golem` | brute | `obsidian` | SLAM, GUARD |
| Gólem de Prismarina | `prismarine_golem` | crystal | `prismarine` | BOLT, PULSE |
| Gólem de Arena | `sand_golem` | drifter | `sandstone` | SANDSTORM, BOLT |
| Gólem de Piedra del End | `end_stone_golem` | drifter | `end_stone` | TELEPORT, BOLT |
| Gólem de Musgo | `moss_golem` | vegetal | `mossy_cobblestone` | HEAL, BARRIER, SPREAD |
| Gólem de Carbón | `coal_golem` | horned | `coal_block` | SMOKE, BOLT |
| Gólem de Hierro | `iron_golem` | brute | `iron_block` | SLAM, GUARD |
| Gólem de Cobre | `copper_golem` | horned | `copper_block` | CHAIN, GUARD |
| Gólem de Oro | `gold_golem` | brute | `gold_block` | HASTE, BOLT |
| Gólem de Redstone | `redstone_golem` | horned | `redstone_block` | PULSE, BOLT |
| Gólem de Lapislázuli | `lapis_golem` | crystal | `lapis_block` | BOLT, PULSE |
| Gólem de Diamante | `diamond_golem` | brute | `diamond_block` | SLAM, GUARD |
| Gólem de Esmeralda | `emerald_golem` | crystal | `emerald_block` | SUPPORT, BOLT |
| Gólem de Cuarzo | `quartz_golem` | crystal | `quartz_block` | BOLT, PULSE |
| Gólem de Amatista | `amethyst_golem` | crystal | `amethyst_block` | SOUNDWAVE, BOLT |
| Gólem de Netherita | `netherite_golem` | brute | `netherite_block` | SLAM, BOLT |

Cambios respecto a tu texto, porque había bloques repetidos: Eléctrico usa `waxed_copper_block` (Cobre usa `copper_block`) y Musgo usa `mossy_cobblestone` (Naturaleza usa `moss_block`). Además el Gólem de Hierro **reemplaza** al golem de hierro vanilla con bloques de hierro. Todo es editable en `config/golemslegendarios.json` (`summonBlocks`, y multiplicadores de vida, daño y habilidades).

## Recompensas
Cada gólem suelta Núcleo, 4–8 Fragmentos y su mineral/material. Con ellos se crafteó espada, pico y armadura completa de su familia (recetas en `data/`). Fragmentos y núcleos reparan sus equipos.

## Anatomía
5 familias voxel (`tools/models_def.py`): brute, crystal, horned, vegetal, drifter. Texturas PNG 128x128 por gólem generadas con `tools/generate.py`.

## Añadir un mineral
Edita `tools/golem_table.py`, ejecuta `python3 tools/generate.py` y `python3 tools/validate.py`. (Minecraft 26.2 añade cinatabrio y azufre, pero no es la versión objetivo.)

## Estado de validación
- **Validación estática** (hecha): JSON válido, todos los recursos presentes, huevos distintos, bloques de invocación sin repetir, llaves balanceadas, sin audio.
- **Compilación:** **no realizada** (sin red ni JDK/Minecraft aquí). Las APIs de 26.1.2 (nombres Mojang, `ModelLayerRegistry`, `Identifier`, render states) se escribieron de memoria y con la guía de portado de Fabric; pueden haber errores de nombre que solo el compilador mostrará.
- **Prueba en juego:** **no realizada**. Invocación, huevos, habilidades y animaciones están sin probar.

## Notas
- Sin archivos de audio ni sonidos nuevos; reutiliza eventos de sonido ya existentes del golem de hierro.
- Ataques a distancia = rayos instantáneos con partículas (sin entidades proyectil). Muerte y daño usan la animación vanilla.
- Compatibilidad: namespace propio `golemslegendarios`, sin dependencias de otros mods.
