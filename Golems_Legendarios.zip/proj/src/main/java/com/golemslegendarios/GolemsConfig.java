package com.golemslegendarios;

import com.golemslegendarios.entity.GolemDef;
import com.golemslegendarios.entity.GolemDefs;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

/** Configuracion en config/golemslegendarios.json (se crea sola la primera vez). */
public final class GolemsConfig {
  private GolemsConfig() {}

  public static double healthMultiplier = 1.0;
  public static double damageMultiplier = 1.0;
  public static double abilityDamageMultiplier = 1.0;
  private static final Map<String, String> SUMMON_BLOCKS = new LinkedHashMap<>();
  private static final Map<String, Block> RESOLVED = new HashMap<>();

  public static void load() {
    for (GolemDef d : GolemDefs.ALL) SUMMON_BLOCKS.put(d.id(), d.blockId());
    Path file = FabricLoader.getInstance().getConfigDir().resolve("golemslegendarios.json");
    Gson gson = new GsonBuilder().setPrettyPrinting().create();
    try {
      if (Files.exists(file)) {
        JsonObject o = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
        if (o.has("healthMultiplier")) healthMultiplier = o.get("healthMultiplier").getAsDouble();
        if (o.has("damageMultiplier")) damageMultiplier = o.get("damageMultiplier").getAsDouble();
        if (o.has("abilityDamageMultiplier")) abilityDamageMultiplier = o.get("abilityDamageMultiplier").getAsDouble();
        if (o.has("summonBlocks") && o.get("summonBlocks").isJsonObject()) {
          for (Map.Entry<String, JsonElement> en : o.getAsJsonObject("summonBlocks").entrySet()) {
            SUMMON_BLOCKS.put(en.getKey(), en.getValue().getAsString());
          }
        }
      } else {
        JsonObject o = new JsonObject();
        o.addProperty("healthMultiplier", 1.0);
        o.addProperty("damageMultiplier", 1.0);
        o.addProperty("abilityDamageMultiplier", 1.0);
        JsonObject blocks = new JsonObject();
        for (Map.Entry<String, String> en : SUMMON_BLOCKS.entrySet()) blocks.addProperty(en.getKey(), en.getValue());
        o.add("summonBlocks", blocks);
        Files.writeString(file, gson.toJson(o));
      }
    } catch (IOException | RuntimeException ex) {
      GolemsLegendarios.LOGGER.warn("No se pudo leer/escribir la configuracion, se usan valores por defecto.", ex);
    }
  }

  /** Resuelve los ids de bloque a bloques reales (los bloques ya estan registrados al llegar aqui). */
  public static void resolveBlocks() {
    Map<Block, String> seen = new HashMap<>();
    for (GolemDef d : GolemDefs.ALL) {
      String s = SUMMON_BLOCKS.getOrDefault(d.id(), d.blockId());
      Block b = BuiltInRegistries.BLOCK.getValue(Identifier.parse(s));
      if (b == null || b == Blocks.AIR) {
        GolemsLegendarios.LOGGER.warn("Bloque de invocacion invalido para {}: {}", d.id(), s);
        continue;
      }
      String prev = seen.put(b, d.id());
      if (prev != null) GolemsLegendarios.LOGGER.warn("{} y {} comparten bloque de invocacion ({}); gana el primero.", prev, d.id(), s);
      RESOLVED.put(d.id(), b);
    }
  }

  public static Block blockFor(GolemDef d) { return RESOLVED.get(d.id()); }
}
