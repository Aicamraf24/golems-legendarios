package com.golemslegendarios.client;

import com.golemslegendarios.GolemsLegendarios;
import com.golemslegendarios.entity.GolemDef;
import com.golemslegendarios.entity.GolemDefs;
import com.golemslegendarios.entity.GolemRegistry;
import java.util.HashSet;
import java.util.Set;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;

public class GolemsLegendariosClient implements ClientModInitializer {
  public static ModelLayerLocation layer(String family) {
    return new ModelLayerLocation(Identifier.fromNamespaceAndPath(GolemsLegendarios.MOD_ID, "golem_" + family), "main");
  }

  @Override
  public void onInitializeClient() {
    Set<String> families = new HashSet<>();
    for (GolemDef def : GolemDefs.ALL) {
      final String family = def.family();
      if (families.add(family)) ModelLayerRegistry.registerModelLayer(layer(family), () -> FamilyModels.create(family));
      EntityRendererRegistry.register(GolemRegistry.TYPES.get(def.id()), ctx -> new GolemRenderer(ctx, def));
    }
  }
}
