package com.golemslegendarios;

import com.golemslegendarios.entity.GolemDefs;
import com.golemslegendarios.entity.GolemRegistry;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GolemsLegendarios implements ModInitializer {
  public static final String MOD_ID = "golemslegendarios";
  public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

  @Override
  public void onInitialize() {
    GolemsConfig.load();
    GolemRegistry.registerAll();
    ModItems.init();
    GolemsConfig.resolveBlocks();
    LOGGER.info("Golems Legendarios: {} golems registrados.", GolemDefs.ALL.length);
  }
}
