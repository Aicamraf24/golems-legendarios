package com.golemslegendarios.client;

import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;

// ARCHIVO GENERADO por tools/generate.py (anatomia en tools/models_def.py). No editar a mano.
public final class FamilyModels {
  private FamilyModels() {}

  public static LayerDefinition create(String family) {
    MeshDefinition mesh = new MeshDefinition();
    PartDefinition root = mesh.getRoot();
    switch (family) {
      case "brute" -> {
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-5.0f, -10.0f, -5.0f, 10.0f, 10.0f, 10.0f).texOffs(40, 0).addBox(-1.0f, -3.0f, -7.0f, 2.0f, 4.0f, 2.0f).texOffs(48, 0).addBox(-5.0f, -10.0f, -6.0f, 10.0f, 2.0f, 1.0f), PartPose.offset(0.0f, -14.0f, 0.0f));
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(70, 0).addBox(-9.0f, -14.0f, -5.0f, 18.0f, 20.0f, 10.0f).texOffs(0, 30).addBox(-7.0f, -12.0f, -6.0f, 14.0f, 9.0f, 1.0f).texOffs(30, 30).addBox(-8.0f, 2.0f, -6.0f, 16.0f, 3.0f, 1.0f), PartPose.offset(0.0f, 0.0f, 0.0f));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(64, 30).addBox(-4.0f, -2.0f, -4.0f, 8.0f, 26.0f, 8.0f).texOffs(0, 64).addBox(-5.0f, -4.0f, -5.0f, 10.0f, 5.0f, 10.0f), PartPose.offset(-13.0f, -12.0f, 0.0f));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().mirror().texOffs(64, 30).addBox(-4.0f, -2.0f, -4.0f, 8.0f, 26.0f, 8.0f).texOffs(0, 64).addBox(-5.0f, -4.0f, -5.0f, 10.0f, 5.0f, 10.0f), PartPose.offset(13.0f, -12.0f, 0.0f));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(40, 64).addBox(-3.5f, 0.0f, -3.5f, 7.0f, 18.0f, 7.0f).texOffs(68, 64).addBox(-4.0f, 14.0f, -5.5f, 8.0f, 4.0f, 9.0f), PartPose.offset(-5.0f, 6.0f, 0.0f));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().mirror().texOffs(40, 64).addBox(-3.5f, 0.0f, -3.5f, 7.0f, 18.0f, 7.0f).texOffs(68, 64).addBox(-4.0f, 14.0f, -5.5f, 8.0f, 4.0f, 9.0f), PartPose.offset(5.0f, 6.0f, 0.0f));
      }
      case "crystal" -> {
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f).texOffs(32, 0).addBox(-1.0f, -14.0f, -1.0f, 2.0f, 6.0f, 2.0f).texOffs(40, 0).addBox(-4.0f, -12.0f, -3.0f, 2.0f, 4.0f, 2.0f).texOffs(48, 0).addBox(2.0f, -12.0f, -3.0f, 2.0f, 4.0f, 2.0f), PartPose.offset(0.0f, -10.0f, 0.0f));
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(56, 0).addBox(-7.0f, -10.0f, -4.0f, 14.0f, 18.0f, 8.0f).texOffs(100, 0).addBox(-3.0f, -6.0f, -5.0f, 6.0f, 6.0f, 1.0f).texOffs(114, 0).addBox(-3.0f, -12.0f, 4.0f, 3.0f, 10.0f, 3.0f).texOffs(0, 26).addBox(1.0f, -8.0f, 4.0f, 2.0f, 8.0f, 2.0f), PartPose.offset(0.0f, 0.0f, 0.0f));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(8, 26).addBox(-3.0f, -2.0f, -3.0f, 6.0f, 22.0f, 6.0f).texOffs(32, 26).addBox(-4.0f, -6.0f, -4.0f, 8.0f, 5.0f, 8.0f).texOffs(64, 26).addBox(-5.0f, -12.0f, -2.0f, 3.0f, 7.0f, 3.0f), PartPose.offset(-10.0f, -8.0f, 0.0f));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().mirror().texOffs(8, 26).addBox(-3.0f, -2.0f, -3.0f, 6.0f, 22.0f, 6.0f).texOffs(32, 26).addBox(-4.0f, -6.0f, -4.0f, 8.0f, 5.0f, 8.0f).texOffs(64, 26).addBox(2.0f, -12.0f, -2.0f, 3.0f, 7.0f, 3.0f), PartPose.offset(10.0f, -8.0f, 0.0f));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(76, 26).addBox(-3.0f, 0.0f, -3.0f, 6.0f, 16.0f, 6.0f).texOffs(0, 54).addBox(-3.5f, 13.0f, -4.0f, 7.0f, 3.0f, 8.0f), PartPose.offset(-3.5f, 8.0f, 0.0f));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().mirror().texOffs(76, 26).addBox(-3.0f, 0.0f, -3.0f, 6.0f, 16.0f, 6.0f).texOffs(0, 54).addBox(-3.5f, 13.0f, -4.0f, 7.0f, 3.0f, 8.0f), PartPose.offset(3.5f, 8.0f, 0.0f));
      }
      case "horned" -> {
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-5.0f, -9.0f, -5.0f, 10.0f, 9.0f, 10.0f).texOffs(40, 0).addBox(-8.0f, -11.0f, -2.0f, 3.0f, 5.0f, 3.0f).texOffs(52, 0).addBox(-9.0f, -15.0f, -2.0f, 2.0f, 4.0f, 2.0f).texOffs(60, 0).addBox(5.0f, -11.0f, -2.0f, 3.0f, 5.0f, 3.0f).texOffs(72, 0).addBox(7.0f, -15.0f, -2.0f, 2.0f, 4.0f, 2.0f).texOffs(80, 0).addBox(-1.0f, -12.0f, -4.0f, 2.0f, 3.0f, 2.0f), PartPose.offset(0.0f, -14.0f, 0.0f));
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 19).addBox(-8.0f, -14.0f, -5.0f, 16.0f, 20.0f, 10.0f).texOffs(52, 19).addBox(-3.0f, -10.0f, -6.0f, 6.0f, 6.0f, 1.0f).texOffs(66, 19).addBox(-6.0f, -18.0f, 3.0f, 3.0f, 6.0f, 3.0f).texOffs(78, 19).addBox(3.0f, -18.0f, 3.0f, 3.0f, 6.0f, 3.0f).texOffs(90, 19).addBox(-7.0f, 3.0f, -6.0f, 14.0f, 3.0f, 1.0f), PartPose.offset(0.0f, 0.0f, 0.0f));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(0, 49).addBox(-4.5f, -2.0f, -4.5f, 9.0f, 24.0f, 9.0f).texOffs(36, 49).addBox(-5.0f, -5.0f, -5.0f, 10.0f, 5.0f, 10.0f).texOffs(76, 49).addBox(-5.0f, -10.0f, -2.0f, 4.0f, 5.0f, 4.0f), PartPose.offset(-12.0f, -12.0f, 0.0f));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().mirror().texOffs(0, 49).addBox(-4.5f, -2.0f, -4.5f, 9.0f, 24.0f, 9.0f).texOffs(36, 49).addBox(-5.0f, -5.0f, -5.0f, 10.0f, 5.0f, 10.0f).texOffs(76, 49).addBox(1.0f, -10.0f, -2.0f, 4.0f, 5.0f, 4.0f), PartPose.offset(12.0f, -12.0f, 0.0f));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(92, 49).addBox(-3.5f, 0.0f, -3.5f, 7.0f, 18.0f, 7.0f).texOffs(0, 82).addBox(-4.0f, 14.0f, -5.0f, 8.0f, 4.0f, 8.0f), PartPose.offset(-4.5f, 6.0f, 0.0f));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().mirror().texOffs(92, 49).addBox(-3.5f, 0.0f, -3.5f, 7.0f, 18.0f, 7.0f).texOffs(0, 82).addBox(-4.0f, 14.0f, -5.0f, 8.0f, 4.0f, 8.0f), PartPose.offset(4.5f, 6.0f, 0.0f));
      }
      case "vegetal" -> {
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f).texOffs(32, 0).addBox(-7.0f, -12.0f, -1.0f, 2.0f, 6.0f, 2.0f).texOffs(40, 0).addBox(-8.0f, -16.0f, -1.0f, 2.0f, 5.0f, 2.0f).texOffs(48, 0).addBox(5.0f, -12.0f, -1.0f, 2.0f, 6.0f, 2.0f).texOffs(56, 0).addBox(6.0f, -16.0f, -1.0f, 2.0f, 5.0f, 2.0f).texOffs(64, 0).addBox(-5.0f, -10.0f, -5.0f, 10.0f, 2.0f, 10.0f), PartPose.offset(0.0f, -18.0f, 0.0f));
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-8.0f, -18.0f, -5.0f, 16.0f, 24.0f, 10.0f).texOffs(52, 16).addBox(-9.0f, -14.0f, -6.0f, 6.0f, 5.0f, 2.0f).texOffs(68, 16).addBox(3.0f, -6.0f, -6.0f, 6.0f, 5.0f, 2.0f).texOffs(84, 16).addBox(-4.0f, -20.0f, 2.0f, 8.0f, 4.0f, 4.0f), PartPose.offset(0.0f, 0.0f, 0.0f));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(0, 50).addBox(-3.5f, -2.0f, -3.5f, 7.0f, 28.0f, 7.0f).texOffs(28, 50).addBox(-5.0f, -4.0f, -5.0f, 10.0f, 6.0f, 10.0f).texOffs(68, 50).addBox(-8.0f, 6.0f, -1.0f, 4.0f, 2.0f, 2.0f), PartPose.offset(-12.0f, -14.0f, 0.0f));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().mirror().texOffs(0, 50).addBox(-3.5f, -2.0f, -3.5f, 7.0f, 28.0f, 7.0f).texOffs(28, 50).addBox(-5.0f, -4.0f, -5.0f, 10.0f, 6.0f, 10.0f).texOffs(68, 50).addBox(4.0f, 6.0f, -1.0f, 4.0f, 2.0f, 2.0f), PartPose.offset(12.0f, -14.0f, 0.0f));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(80, 50).addBox(-4.0f, 0.0f, -4.0f, 8.0f, 18.0f, 8.0f).texOffs(0, 85).addBox(-5.0f, 12.0f, -5.0f, 10.0f, 3.0f, 10.0f), PartPose.offset(-4.5f, 6.0f, 0.0f));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().mirror().texOffs(80, 50).addBox(-4.0f, 0.0f, -4.0f, 8.0f, 18.0f, 8.0f).texOffs(0, 85).addBox(-5.0f, 12.0f, -5.0f, 10.0f, 3.0f, 10.0f), PartPose.offset(4.5f, 6.0f, 0.0f));
      }
      case "drifter" -> {
        root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f).texOffs(32, 0).addBox(-5.0f, -4.0f, -5.0f, 1.0f, 3.0f, 10.0f).texOffs(54, 0).addBox(4.0f, -4.0f, -5.0f, 1.0f, 3.0f, 10.0f), PartPose.offset(0.0f, -16.0f, 0.0f));
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(76, 0).addBox(-8.0f, -10.0f, -5.0f, 16.0f, 16.0f, 10.0f).texOffs(0, 26).addBox(-3.0f, -6.0f, -6.0f, 6.0f, 6.0f, 1.0f).texOffs(14, 26).addBox(-6.0f, -12.0f, -4.0f, 12.0f, 2.0f, 8.0f), PartPose.offset(0.0f, 0.0f, 0.0f));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(54, 26).addBox(-3.0f, -2.0f, -3.0f, 6.0f, 8.0f, 6.0f).texOffs(78, 26).addBox(-4.0f, 10.0f, -4.0f, 8.0f, 9.0f, 8.0f).texOffs(110, 26).addBox(-2.0f, 7.0f, -2.0f, 4.0f, 2.0f, 4.0f), PartPose.offset(-13.0f, -6.0f, 0.0f));
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().mirror().texOffs(54, 26).addBox(-3.0f, -2.0f, -3.0f, 6.0f, 8.0f, 6.0f).texOffs(78, 26).addBox(-4.0f, 10.0f, -4.0f, 8.0f, 9.0f, 8.0f).texOffs(110, 26).addBox(-2.0f, 7.0f, -2.0f, 4.0f, 2.0f, 4.0f), PartPose.offset(13.0f, -6.0f, 0.0f));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(0, 43).addBox(-3.0f, 0.0f, -3.0f, 6.0f, 8.0f, 6.0f).texOffs(24, 43).addBox(-2.0f, 9.0f, -2.0f, 4.0f, 3.0f, 4.0f), PartPose.offset(-5.0f, 12.0f, 0.0f));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().mirror().texOffs(0, 43).addBox(-3.0f, 0.0f, -3.0f, 6.0f, 8.0f, 6.0f).texOffs(24, 43).addBox(-2.0f, 9.0f, -2.0f, 4.0f, 3.0f, 4.0f), PartPose.offset(5.0f, 12.0f, 0.0f));
      }
      default -> throw new IllegalArgumentException("Familia desconocida: " + family);
    }
    return LayerDefinition.create(mesh, 128, 128);
  }

  /** Parametros de animacion por familia: {amplitud piernas, amplitud brazos, flotacion}. */
  public static float[] anim(String family) {
    return switch (family) {
      case "brute" -> new float[] {1.0f, 0.7f, 0.0f};
      case "crystal" -> new float[] {1.2f, 0.9f, 0.0f};
      case "horned" -> new float[] {1.0f, 0.8f, 0.0f};
      case "vegetal" -> new float[] {0.9f, 0.6f, 0.0f};
      case "drifter" -> new float[] {0.5f, 0.5f, 1.0f};
      default -> new float[] {1.0f, 0.7f, 0.0f};
    };
  }
}
