package com.golemslegendarios.entity;

import com.golemslegendarios.GolemsLegendarios;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class GolemRegistry {
  private GolemRegistry() {}

  public static final Map<String, EntityType<GolemEntity>> TYPES = new LinkedHashMap<>();
  private static final Map<EntityType<?>, GolemDef> BY_TYPE = new HashMap<>();

  public static GolemDef defOf(EntityType<?> type) { return BY_TYPE.get(type); }

  public static void registerAll() {
    for (GolemDef def : GolemDefs.ALL) {
      Identifier id = Identifier.fromNamespaceAndPath(GolemsLegendarios.MOD_ID, def.id());
      ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, id);
      EntityType.Builder<GolemEntity> builder = EntityType.Builder.<GolemEntity>of(GolemEntity::new, MobCategory.MISC)
          .sized(def.width(), def.height())
          .clientTrackingRange(10);
      if (def.fireImmune()) builder = builder.fireImmune();
      EntityType<GolemEntity> type = builder.build(key);
      Registry.register(BuiltInRegistries.ENTITY_TYPE, key, type);
      TYPES.put(def.id(), type);
      BY_TYPE.put(type, def);
      FabricDefaultAttributeRegistry.register(type, GolemEntity.createAttributes(def));
    }
  }
}
