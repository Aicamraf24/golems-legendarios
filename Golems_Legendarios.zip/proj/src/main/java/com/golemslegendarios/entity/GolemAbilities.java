package com.golemslegendarios.entity;

import com.golemslegendarios.GolemsConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Implementacion de todas las habilidades. Ataques a distancia = rayos instantaneos con particulas (sin entidades). */
public final class GolemAbilities {
  private GolemAbilities() {}

  // ------------------------------------------------------------------ utilidades
  static boolean isFoe(GolemEntity g, LivingEntity e) {
    if (e == g || !e.isAlive() || e instanceof GolemEntity) return false;
    if (e == g.getTarget()) return true;
    return e instanceof Enemy && !(e instanceof Creeper);
  }

  static List<LivingEntity> foes(ServerLevel sl, GolemEntity g, Vec3 c, double r) {
    return sl.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r), e -> isFoe(g, e) && e.distanceToSqr(c) <= r * r);
  }

  private static SimpleParticleType particle(String id) {
    if (id == null || id.isEmpty()) return null;
    ParticleType<?> t = BuiltInRegistries.PARTICLE_TYPE.getValue(Identifier.parse(id));
    return t instanceof SimpleParticleType s ? s : null;
  }

  private static void burst(ServerLevel sl, SimpleParticleType p, Vec3 c, int count, double spread) {
    if (p != null) sl.sendParticles(p, c.x, c.y, c.z, count, spread, spread, spread, 0.02);
  }

  private static void ring(ServerLevel sl, SimpleParticleType p, Vec3 c, double radius) {
    if (p == null) return;
    for (int i = 0; i < 16; i++) {
      double a = i * Math.PI / 8.0;
      sl.sendParticles(p, c.x + Math.cos(a) * radius, c.y + 0.2, c.z + Math.sin(a) * radius, 1, 0, 0, 0, 0);
    }
  }

  private static void beam(ServerLevel sl, SimpleParticleType p, Vec3 a, Vec3 b) {
    if (p == null) return;
    int steps = (int) Math.min(24, Math.max(2, a.distanceTo(b) * 1.5));
    for (int i = 0; i <= steps; i++) {
      Vec3 q = a.lerp(b, i / (double) steps);
      sl.sendParticles(p, q.x, q.y, q.z, 1, 0.03, 0.03, 0.03, 0);
    }
  }

  private static void hurt(ServerLevel sl, GolemEntity g, LivingEntity e, float amount) {
    e.hurtServer(sl, sl.damageSources().mobAttack(g), amount * (float) GolemsConfig.abilityDamageMultiplier);
  }

  private static void push(GolemEntity g, LivingEntity e, double strength) {
    e.knockback(strength, g.getX() - e.getX(), g.getZ() - e.getZ());
  }

  public static void applyEffect(LivingEntity e, String effect, int ticks, int amp) {
    if (effect == null || effect.isEmpty()) return;
    if (effect.equals("fire")) {
      e.igniteForSeconds(Math.max(1.0f, ticks / 20.0f));
      return;
    }
    BuiltInRegistries.MOB_EFFECT.get(Identifier.parse("minecraft:" + effect))
        .ifPresent(h -> e.addEffect(new MobEffectInstance(h, ticks, amp)));
  }

  // ------------------------------------------------------------------ condiciones
  public static boolean canUse(GolemEntity g, GolemDef.AbilitySpec s, LivingEntity t) {
    switch (s.kind()) {
      case BOLT, CHAIN, ROOTS -> {
        double d = g.distanceTo(t);
        return d >= 2.5 && d <= s.range() && g.hasLineOfSight(t);
      }
      case SLAM, PULSE, SMOKE, SANDSTORM, SOUNDWAVE, GUARD, HASTE -> { return g.distanceTo(t) <= s.range(); }
      case TELEPORT -> {
        double d = g.distanceTo(t);
        return d >= 7.0 && d <= s.range();
      }
      case BARRIER -> {
        double d = g.distanceTo(t);
        return d >= 3.0 && d <= s.range();
      }
      case HEAL -> { return g.getHealth() < g.getMaxHealth() * 0.8f; }
      case SUPPORT -> {
        if (g.getHealth() < g.getMaxHealth() * 0.75f) return true;
        if (!(g.level() instanceof ServerLevel sl)) return false;
        return !allies(sl, g, s.range()).stream().filter(a -> a.getHealth() < a.getMaxHealth() * 0.75f).toList().isEmpty();
      }
      case SPREAD -> { return g.onGround() && g.getTarget() == null; }
    }
    return false;
  }

  private static List<LivingEntity> allies(ServerLevel sl, GolemEntity g, double r) {
    return sl.getEntitiesOfClass(LivingEntity.class, g.getBoundingBox().inflate(r),
        e -> e.isAlive() && (e == g || e instanceof Player || e instanceof GolemEntity));
  }

  // ------------------------------------------------------------------ uso
  public static void use(ServerLevel sl, GolemEntity g, GolemDef.AbilitySpec s, LivingEntity t) {
    SimpleParticleType p = particle(s.particle());
    switch (s.kind()) {
      case BOLT -> {
        beam(sl, p, g.getEyePosition(), t.getEyePosition());
        hurt(sl, g, t, s.power());
        applyEffect(t, s.effect(), s.effectTicks(), s.effectAmp());
        if (s.extra().contains("knock")) push(g, t, 0.9);
      }
      case CHAIN -> {
        List<LivingEntity> hit = new ArrayList<>();
        hit.add(t);
        beam(sl, p, g.getEyePosition(), t.getEyePosition());
        LivingEntity cur = t;
        for (int i = 0; i < 3; i++) {
          LivingEntity next = null;
          double best = 36.0;
          for (LivingEntity e : foes(sl, g, cur.position(), 6.0)) {
            if (hit.contains(e)) continue;
            double d = e.distanceToSqr(cur);
            if (d < best) { best = d; next = e; }
          }
          if (next == null) break;
          beam(sl, p, cur.getEyePosition(), next.getEyePosition());
          hit.add(next);
          cur = next;
        }
        for (LivingEntity e : hit) {
          hurt(sl, g, e, s.power());
          applyEffect(e, s.effect(), s.effectTicks(), s.effectAmp());
        }
      }
      case SLAM, PULSE, SMOKE, SANDSTORM, SOUNDWAVE -> {
        Vec3 c = g.position();
        ring(sl, p, c, s.range() * 0.5);
        ring(sl, p, c, s.range());
        burst(sl, p, c.add(0, 0.5, 0), s.kind() == Ability.SLAM ? 12 : 30, s.range() * 0.3);
        for (LivingEntity e : foes(sl, g, c, s.range())) {
          hurt(sl, g, e, s.power());
          applyEffect(e, s.effect(), s.effectTicks(), s.effectAmp());
          if (s.kind() == Ability.SLAM) push(g, e, 1.2);
          else if (s.kind() == Ability.SOUNDWAVE) push(g, e, 1.6);
        }
      }
      case ROOTS -> {
        burst(sl, p, t.position().add(0, 0.2, 0), 25, 0.6);
        for (LivingEntity e : foes(sl, g, t.position(), 3.0)) {
          hurt(sl, g, e, s.power());
          applyEffect(e, s.effect(), s.effectTicks(), s.effectAmp());
        }
      }
      case TELEPORT -> {
        Vec3 from = g.position();
        Vec3 dir = g.position().subtract(t.position());
        if (dir.length() < 0.1) return;
        Vec3 dest = t.position().add(dir.normalize().scale(2.5));
        burst(sl, p, from.add(0, 1, 0), 25, 0.5);
        if (g.randomTeleport(dest.x, dest.y, dest.z, true)) burst(sl, p, g.position().add(0, 1, 0), 25, 0.5);
      }
      case BARRIER -> barrier(sl, g, s, t);
      case GUARD -> {
        applyEffect(g, s.effect(), s.effectTicks(), s.effectAmp());
        ring(sl, p, g.position(), 1.5);
      }
      case HASTE -> {
        applyEffect(g, s.effect(), s.effectTicks(), s.effectAmp());
        applyEffect(g, "strength", s.effectTicks(), 1);
        ring(sl, p, g.position(), 1.5);
      }
      case HEAL -> {
        g.heal(s.power());
        burst(sl, p, g.position().add(0, 1.5, 0), 12, 0.7);
      }
      case SUPPORT -> {
        for (LivingEntity a : allies(sl, g, s.range())) {
          a.heal(s.power());
          applyEffect(a, s.effect(), s.effectTicks(), s.effectAmp());
          burst(sl, p, a.position().add(0, 1.2, 0), 8, 0.4);
        }
      }
      case SPREAD -> spread(sl, g, p);
    }
  }

  // ------------------------------------------------------------------ barreras vegetales (temporales)
  private static void barrier(ServerLevel sl, GolemEntity g, GolemDef.AbilitySpec s, LivingEntity t) {
    String[] parts = s.extra().split("\\|");
    if (parts.length < 2) return;
    Block block = BuiltInRegistries.BLOCK.getValue(Identifier.parse(parts[1]));
    if (block == null || block == Blocks.AIR) return;
    BlockState st = block.defaultBlockState();
    if (st.hasProperty(BlockStateProperties.AGE_3)) st = st.setValue(BlockStateProperties.AGE_3, 3);
    boolean wall = parts[0].equals("wall");
    Vec3 toward = t.position().subtract(g.position());
    toward = new Vec3(toward.x, 0, toward.z);
    if (toward.length() < 0.1) return;
    toward = toward.normalize();
    Vec3 perp = new Vec3(-toward.z, 0, toward.x);
    if (wall) {
      Vec3 center = g.position().add(toward.scale(2.5));
      for (int k = -2; k <= 2; k++) placeAt(sl, g, center.add(perp.scale(k)), st, true);
    } else {
      for (int i = 0; i < 6; i++) {
        double a = i * Math.PI / 3.0;
        placeAt(sl, g, g.position().add(Math.cos(a) * 2.5, 0, Math.sin(a) * 2.5), st, false);
      }
    }
  }

  private static void placeAt(ServerLevel sl, GolemEntity g, Vec3 pos, BlockState st, boolean tall) {
    BlockPos base = BlockPos.containing(pos.x, g.getY(), pos.z);
    for (int dy : new int[] {0, 1, -1}) {
      BlockPos p = base.offset(0, dy, 0);
      if (!sl.isEmptyBlock(p)) continue;
      if (!sl.getBlockState(p.below()).isFaceSturdy(sl, p.below(), Direction.UP)) continue;
      if (!st.canSurvive(sl, p)) continue;
      sl.setBlock(p, st, Block.UPDATE_ALL);
      g.trackPlaced(p, st.getBlock(), 300);
      if (tall && sl.isEmptyBlock(p.above())) {
        sl.setBlock(p.above(), st, Block.UPDATE_ALL);
        g.trackPlaced(p.above(), st.getBlock(), 300);
      }
      return;
    }
  }

  // ------------------------------------------------------------------ musgo por el suelo (permanente, poco volumen)
  private static void spread(ServerLevel sl, GolemEntity g, SimpleParticleType p) {
    RandomSource r = g.getRandom();
    int converted = 0;
    for (int i = 0; i < 14 && converted < 6; i++) {
      int ox = r.nextInt(9) - 4, oz = r.nextInt(9) - 4;
      for (int dy = 1; dy >= -3; dy--) {
        BlockPos q = g.blockPosition().offset(ox, dy, oz);
        BlockState bs = sl.getBlockState(q);
        boolean ground = bs.is(BlockTags.DIRT) || bs.is(BlockTags.BASE_STONE_OVERWORLD);
        if (ground && sl.isEmptyBlock(q.above())) {
          sl.setBlock(q, Blocks.MOSS_BLOCK.defaultBlockState(), Block.UPDATE_ALL);
          if (r.nextBoolean()) sl.setBlock(q.above(), Blocks.MOSS_CARPET.defaultBlockState(), Block.UPDATE_ALL);
          burst(sl, p, Vec3.atCenterOf(q).add(0, 0.8, 0), 4, 0.3);
          converted++;
          break;
        }
        if (!bs.isAir()) break;
      }
    }
  }
}
