package com.golemslegendarios.entity;

// ARCHIVO GENERADO por tools/generate.py a partir de tools/golem_table.py. No editar a mano.
public final class GolemDefs {
  private GolemDefs() {}

  public static final GolemDef[] ALL = new GolemDef[] {
    new GolemDef("fire_golem", "fire", "horned", "minecraft:magma_block", 100.0, 12.0, 0.26, 6.0, 0.6, 1.8f, 3.0f, true, false, 0, 0.0f, 2, "fire", 100, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.BOLT, 50, 6.0f, 18.0, "minecraft:flame", "fire", 100, 0, ""),
      new GolemDef.AbilitySpec(Ability.PULSE, 160, 8.0f, 5.0, "minecraft:flame", "fire", 80, 0, "")
    }),
    new GolemDef("ice_golem", "ice", "crystal", "minecraft:packed_ice", 90.0, 11.0, 0.25, 4.0, 0.5, 1.3f, 2.75f, false, false, 0, 0.0f, 1, "slowness", 80, 1, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.BOLT, 50, 5.0f, 18.0, "minecraft:snowflake", "slowness", 100, 2, ""),
      new GolemDef.AbilitySpec(Ability.PULSE, 150, 6.0f, 5.0, "minecraft:snowflake", "slowness", 100, 3, "")
    }),
    new GolemDef("electric_golem", "electric", "horned", "minecraft:waxed_copper_block", 85.0, 11.0, 0.3, 4.0, 0.4, 1.8f, 3.0f, false, false, 0, 0.0f, 2, "weakness", 60, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.BOLT, 45, 7.0f, 18.0, "minecraft:electric_spark", "", 0, 0, ""),
      new GolemDef.AbilitySpec(Ability.CHAIN, 120, 6.0f, 16.0, "minecraft:electric_spark", "", 0, 0, "")
    }),
    new GolemDef("rock_golem", "rock", "brute", "minecraft:stone", 170.0, 18.0, 0.2, 14.0, 1.0, 1.6f, 3.0f, false, false, 0, 0.0f, 1, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.SLAM, 90, 12.0f, 6.0, "minecraft:poof", "", 0, 0, ""),
      new GolemDef.AbilitySpec(Ability.GUARD, 400, 0.0f, 12.0, "minecraft:crit", "resistance", 120, 1, "")
    }),
    new GolemDef("nature_golem", "nature", "vegetal", "minecraft:moss_block", 110.0, 12.0, 0.24, 5.0, 0.5, 1.6f, 3.25f, false, false, 40, 1.0f, 1, "poison", 60, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.ROOTS, 140, 4.0f, 14.0, "minecraft:composter", "slowness", 80, 6, ""),
      new GolemDef.AbilitySpec(Ability.BARRIER, 260, 0.0f, 14.0, "", "", 0, 0, "ring|minecraft:sweet_berry_bush"),
      new GolemDef.AbilitySpec(Ability.HEAL, 300, 10.0f, 0.0, "minecraft:happy_villager", "", 0, 0, "")
    }),
    new GolemDef("obsidian_golem", "obsidian", "brute", "minecraft:obsidian", 230.0, 26.0, 0.16, 16.0, 1.0, 1.6f, 3.0f, true, false, 0, 0.0f, 3, "slowness", 60, 1, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.SLAM, 110, 18.0f, 6.0, "minecraft:crit", "", 0, 0, ""),
      new GolemDef.AbilitySpec(Ability.GUARD, 350, 0.0f, 12.0, "minecraft:witch", "resistance", 140, 1, "")
    }),
    new GolemDef("prismarine_golem", "prismarine", "crystal", "minecraft:prismarine", 105.0, 11.0, 0.25, 6.0, 0.5, 1.3f, 2.75f, false, true, 0, 0.0f, 1, "mining_fatigue", 100, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.BOLT, 50, 6.0f, 18.0, "minecraft:bubble", "slowness", 80, 1, ""),
      new GolemDef.AbilitySpec(Ability.PULSE, 150, 6.0f, 5.0, "minecraft:bubble_pop", "mining_fatigue", 100, 1, "")
    }),
    new GolemDef("sand_golem", "sand", "drifter", "minecraft:sandstone", 90.0, 10.0, 0.27, 3.0, 0.4, 1.5f, 3.0f, false, false, 0, 0.0f, 1, "blindness", 40, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.SANDSTORM, 150, 3.0f, 8.0, "minecraft:cloud", "blindness", 100, 0, ""),
      new GolemDef.AbilitySpec(Ability.BOLT, 45, 5.0f, 16.0, "minecraft:poof", "slowness", 40, 0, "knock")
    }),
    new GolemDef("end_stone_golem", "end_stone", "drifter", "minecraft:end_stone", 100.0, 12.0, 0.26, 5.0, 0.5, 1.5f, 3.0f, false, false, 0, 0.0f, 2, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.TELEPORT, 100, 0.0f, 18.0, "minecraft:portal", "", 0, 0, ""),
      new GolemDef.AbilitySpec(Ability.BOLT, 50, 6.0f, 18.0, "minecraft:end_rod", "", 0, 0, "")
    }),
    new GolemDef("moss_golem", "moss", "vegetal", "minecraft:mossy_cobblestone", 120.0, 11.0, 0.22, 8.0, 0.6, 1.6f, 3.25f, false, false, 30, 1.0f, 1, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.HEAL, 240, 12.0f, 0.0, "minecraft:happy_villager", "", 0, 0, ""),
      new GolemDef.AbilitySpec(Ability.BARRIER, 220, 0.0f, 14.0, "", "", 0, 0, "wall|minecraft:moss_block"),
      new GolemDef.AbilitySpec(Ability.SPREAD, 100, 0.0f, 4.0, "minecraft:composter", "", 0, 0, "")
    }),
    new GolemDef("coal_golem", "coal", "horned", "minecraft:coal_block", 90.0, 11.0, 0.24, 5.0, 0.5, 1.8f, 3.0f, false, false, 0, 0.0f, 1, "fire", 60, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.SMOKE, 150, 3.0f, 6.0, "minecraft:large_smoke", "blindness", 80, 0, ""),
      new GolemDef.AbilitySpec(Ability.BOLT, 55, 5.0f, 16.0, "minecraft:smoke", "fire", 60, 0, "")
    }),
    new GolemDef("iron_golem", "iron", "brute", "minecraft:iron_block", 190.0, 20.0, 0.22, 10.0, 1.0, 1.6f, 3.0f, false, false, 0, 0.0f, 1, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.SLAM, 100, 14.0f, 5.0, "minecraft:crit", "", 0, 0, ""),
      new GolemDef.AbilitySpec(Ability.GUARD, 360, 0.0f, 12.0, "minecraft:crit", "resistance", 120, 1, "")
    }),
    new GolemDef("copper_golem", "copper", "horned", "minecraft:copper_block", 95.0, 11.0, 0.26, 6.0, 0.5, 1.8f, 3.0f, false, false, 0, 0.0f, 1, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.CHAIN, 140, 5.0f, 14.0, "minecraft:electric_spark", "", 0, 0, ""),
      new GolemDef.AbilitySpec(Ability.GUARD, 380, 0.0f, 12.0, "minecraft:electric_spark", "resistance", 100, 1, "")
    }),
    new GolemDef("gold_golem", "gold", "brute", "minecraft:gold_block", 85.0, 14.0, 0.36, 4.0, 0.3, 1.6f, 3.0f, false, false, 0, 0.0f, 2, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.HASTE, 200, 0.0f, 14.0, "minecraft:crit", "speed", 100, 2, ""),
      new GolemDef.AbilitySpec(Ability.BOLT, 50, 7.0f, 14.0, "minecraft:crit", "", 0, 0, "")
    }),
    new GolemDef("redstone_golem", "redstone", "horned", "minecraft:redstone_block", 90.0, 11.0, 0.25, 5.0, 0.5, 1.8f, 3.0f, false, false, 0, 0.0f, 1, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.PULSE, 120, 7.0f, 6.0, "minecraft:angry_villager", "weakness", 80, 0, ""),
      new GolemDef.AbilitySpec(Ability.BOLT, 50, 6.0f, 16.0, "minecraft:crimson_spore", "slowness", 40, 0, "")
    }),
    new GolemDef("lapis_golem", "lapis", "crystal", "minecraft:lapis_block", 90.0, 10.0, 0.25, 4.0, 0.5, 1.3f, 2.75f, false, false, 0, 0.0f, 1, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.BOLT, 45, 6.0f, 18.0, "minecraft:enchant", "weakness", 80, 0, ""),
      new GolemDef.AbilitySpec(Ability.PULSE, 160, 5.0f, 5.0, "minecraft:enchant", "nausea", 80, 0, "")
    }),
    new GolemDef("diamond_golem", "diamond", "brute", "minecraft:diamond_block", 210.0, 24.0, 0.24, 16.0, 0.9, 1.6f, 3.0f, false, false, 0, 0.0f, 2, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.SLAM, 100, 16.0f, 5.0, "minecraft:crit", "", 0, 0, ""),
      new GolemDef.AbilitySpec(Ability.GUARD, 340, 0.0f, 12.0, "minecraft:end_rod", "resistance", 140, 1, "")
    }),
    new GolemDef("emerald_golem", "emerald", "crystal", "minecraft:emerald_block", 130.0, 10.0, 0.26, 6.0, 0.5, 1.3f, 2.75f, false, false, 0, 0.0f, 1, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.SUPPORT, 200, 6.0f, 8.0, "minecraft:happy_villager", "absorption", 200, 1, ""),
      new GolemDef.AbilitySpec(Ability.BOLT, 55, 5.0f, 16.0, "minecraft:happy_villager", "", 0, 0, "")
    }),
    new GolemDef("quartz_golem", "quartz", "crystal", "minecraft:quartz_block", 95.0, 12.0, 0.26, 5.0, 0.5, 1.3f, 2.75f, false, false, 0, 0.0f, 1, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.BOLT, 45, 7.0f, 18.0, "minecraft:end_rod", "blindness", 40, 0, ""),
      new GolemDef.AbilitySpec(Ability.PULSE, 150, 5.0f, 6.0, "minecraft:end_rod", "blindness", 60, 0, "")
    }),
    new GolemDef("amethyst_golem", "amethyst", "crystal", "minecraft:amethyst_block", 95.0, 12.0, 0.25, 5.0, 0.5, 1.3f, 2.75f, false, false, 0, 0.0f, 1, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.SOUNDWAVE, 130, 8.0f, 7.0, "minecraft:sonic_boom", "", 0, 0, ""),
      new GolemDef.AbilitySpec(Ability.BOLT, 50, 6.0f, 18.0, "minecraft:witch", "slowness", 40, 0, "")
    }),
    new GolemDef("netherite_golem", "netherite", "brute", "minecraft:netherite_block", 260.0, 30.0, 0.2, 20.0, 1.0, 1.6f, 3.0f, true, false, 0, 0.0f, 3, "", 0, 0, new GolemDef.AbilitySpec[] {
      new GolemDef.AbilitySpec(Ability.SLAM, 110, 20.0f, 6.0, "minecraft:flame", "", 0, 0, ""),
      new GolemDef.AbilitySpec(Ability.BOLT, 70, 10.0f, 16.0, "minecraft:flame", "fire", 100, 0, "")
    })
  };
}
