package com.golemslegendarios.mixin;

import com.golemslegendarios.entity.GolemSummoner;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.CarvedPumpkinBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Se ejecuta ANTES de la logica vanilla (golem de nieve/hierro/cobre) para que las estructuras de este mod
 * (p. ej. T de bloques de hierro o de cobre) tengan prioridad y no las consuma el golem vanilla.
 */
@Mixin(CarvedPumpkinBlock.class)
public abstract class CarvedPumpkinBlockMixin {
  @Inject(method = "onPlace", at = @At("HEAD"), cancellable = true)
  private void golemslegendarios$onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState,
                                         boolean movedByPiston, CallbackInfo ci) {
    if (level instanceof ServerLevel sl && !oldState.is(state.getBlock())) {
      if (GolemSummoner.trySummon(sl, pos)) ci.cancel();
    }
  }
}
