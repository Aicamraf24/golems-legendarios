package com.golemslegendarios.entity;

public record GolemDef(
    String id, String key, String family, String blockId,
    double health, double damage, double speed, double armor, double knockbackResist,
    float width, float height, boolean fireImmune, boolean waterBreather,
    int regenInterval, float regenAmount, int tier,
    String hitEffect, int hitTicks, int hitAmp,
    AbilitySpec[] abilities) {

  public record AbilitySpec(Ability kind, int cooldown, float power, double range,
                            String particle, String effect, int effectTicks, int effectAmp, String extra) {}
}
