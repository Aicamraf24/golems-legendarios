package com.golemslegendarios.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/** Modelo voxel compartido por familia: 6 partes (cabeza, torso, 2 brazos, 2 piernas) con animacion por parametros. */
public class GolemModel extends EntityModel<GolemRenderState> {
  private static final float PI = (float) Math.PI;
  private final ModelPart head, body, rArm, lArm, rLeg, lLeg;
  private final float legAmp, armAmp, bob;
  private final float headY, rArmY, lArmY, rLegY, lLegY;

  public GolemModel(ModelPart root, String family) {
    super(root);
    this.head = root.getChild("head");
    this.body = root.getChild("body");
    this.rArm = root.getChild("right_arm");
    this.lArm = root.getChild("left_arm");
    this.rLeg = root.getChild("right_leg");
    this.lLeg = root.getChild("left_leg");
    float[] a = FamilyModels.anim(family);
    this.legAmp = a[0];
    this.armAmp = a[1];
    this.bob = a[2];
    this.headY = head.y; this.rArmY = rArm.y; this.lArmY = lArm.y; this.rLegY = rLeg.y; this.lLegY = lLeg.y;
  }

  @Override
  public void setupAnim(GolemRenderState s) {
    super.setupAnim(s);
    float t = s.ageInTicks;
    float pos = s.walkAnimationPos;
    float sp = Math.min(1.0F, s.walkAnimationSpeed);
    float idle = Mth.sin(t * 0.07F) * 0.04F;

    // cabeza sigue la mirada
    head.yRot = s.yRot * (PI / 180.0F);
    head.xRot = s.xRot * (PI / 180.0F);
    // caminar / correr (la amplitud crece sola con la velocidad)
    rLeg.xRot = Mth.cos(pos * 0.6662F) * 1.4F * sp * legAmp;
    lLeg.xRot = Mth.cos(pos * 0.6662F + PI) * 1.4F * sp * legAmp;
    rArm.xRot = Mth.cos(pos * 0.6662F + PI) * 1.0F * sp * armAmp + idle;
    lArm.xRot = Mth.cos(pos * 0.6662F) * 1.0F * sp * armAmp - idle;
    // reposo: respiracion
    rArm.zRot = 0.05F + Mth.cos(t * 0.09F) * 0.03F;
    lArm.zRot = -0.05F - Mth.cos(t * 0.09F) * 0.03F;
    body.xRot = 0.0F;
    // flotacion (familia drifter)
    if (bob > 0.0F) {
      head.y = headY + Mth.sin(t * 0.1F + 2.0F) * bob * 1.2F;
      rArm.y = rArmY + Mth.sin(t * 0.1F + 1.0F) * bob * 1.5F;
      lArm.y = lArmY + Mth.sin(t * 0.1F + 3.0F) * bob * 1.5F;
      rLeg.y = rLegY + Mth.sin(t * 0.1F + 4.0F) * bob * 1.0F;
      lLeg.y = lLegY + Mth.sin(t * 0.1F + 5.0F) * bob * 1.0F;
    }
    // ataque cuerpo a cuerpo (swing vanilla)
    if (s.attack > 0.0F) {
      float a = Mth.sin(s.attack * PI);
      rArm.xRot = -2.3F * a;
      lArm.xRot = -2.0F * a;
      body.xRot = 0.15F * a;
    }
    // habilidad: brazos arriba y cabeza atras
    if (s.ability >= 0.0F) {
      float a = Mth.sin(s.ability * PI);
      rArm.xRot = -2.8F * a;
      lArm.xRot = -2.8F * a;
      rArm.zRot = -0.4F * a;
      lArm.zRot = 0.4F * a;
      head.xRot -= 0.35F * a;
      body.xRot = -0.1F * a;
    }
  }
}
