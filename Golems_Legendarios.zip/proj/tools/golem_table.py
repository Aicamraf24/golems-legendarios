# -*- coding: utf-8 -*-
"""Tabla maestra de Golems Legendarios. Todo (Java generado, texturas, lang, recetas, loot) sale de aqui."""

# kind, cooldown, power, range, particle, effect, effect_ticks, effect_amp, extra
def A(kind, cd, power, rng, particle="", effect="", et=0, ea=0, extra=""):
    return dict(kind=kind, cd=cd, power=power, range=rng, particle=particle, effect=effect, et=et, ea=ea, extra=extra)

ELEM = {  # clave -> (es, en)
 "fire":("Fuego","Fire"),"ice":("Hielo","Ice"),"electric":("Electricidad","Electric"),"rock":("Roca","Rock"),
 "nature":("Naturaleza","Nature"),"obsidian":("Obsidiana","Obsidian"),"prismarine":("Prismarina","Prismarine"),
 "sand":("Arena","Sand"),"end_stone":("Piedra del End","End Stone"),"moss":("Musgo","Moss"),
 "coal":("Carbón","Coal"),"iron":("Hierro","Iron"),"copper":("Cobre","Copper"),"gold":("Oro","Gold"),
 "redstone":("Redstone","Redstone"),"lapis":("Lapislázuli","Lapis Lazuli"),"diamond":("Diamante","Diamond"),
 "emerald":("Esmeralda","Emerald"),"quartz":("Cuarzo","Quartz"),"amethyst":("Amatista","Amethyst"),
 "netherite":("Netherita","Netherite"),
}

# key, family, block, base, alt, glow, eye, style, vein, hp, dmg, spd, armor, kb, fireImm, water, regenInt, regenAmt, tier, hit, abilities, drops, category
G = []
def g(**k): G.append(k)

g(key="fire", cat="elemental", family="horned", block="minecraft:magma_block", base="#3a2018", alt="#b23a12", glow="#ff8a1a", eye="#ffd23a",
  style="stone", vein=0.6, hp=100, dmg=12, spd=0.26, armor=6, kb=0.6, fire=True, water=False, regen=(0,0), tier=2, hit=("fire",100,0),
  abil=[A("BOLT",50,6,18,"minecraft:flame","fire",100,0), A("PULSE",160,8,5,"minecraft:flame","fire",80,0)],
  drops=[("minecraft:blaze_powder",2,4),("minecraft:magma_cream",1,3)])
g(key="ice", cat="elemental", family="crystal", block="minecraft:packed_ice", base="#4f8fd8", alt="#bfeaff", glow="#e8fbff", eye="#00d4ff",
  style="crystal", vein=0.12, hp=90, dmg=11, spd=0.25, armor=4, kb=0.5, fire=False, water=False, regen=(0,0), tier=1, hit=("slowness",80,1),
  abil=[A("BOLT",50,5,18,"minecraft:snowflake","slowness",100,2), A("PULSE",150,6,5,"minecraft:snowflake","slowness",100,3)],
  drops=[("minecraft:packed_ice",2,4),("minecraft:snowball",4,8)])
g(key="electric", cat="elemental", family="horned", block="minecraft:waxed_copper_block", base="#26262c", alt="#4b4b55", glow="#ffe629", eye="#fff36a",
  style="metal", vein=0.7, hp=85, dmg=11, spd=0.30, armor=4, kb=0.4, fire=False, water=False, regen=(0,0), tier=2, hit=("weakness",60,0),
  abil=[A("BOLT",45,7,18,"minecraft:electric_spark","",0,0), A("CHAIN",120,6,16,"minecraft:electric_spark","",0,0)],
  drops=[("minecraft:copper_ingot",3,6),("minecraft:redstone",2,5)])
g(key="rock", cat="elemental", family="brute", block="minecraft:stone", base="#7a7a78", alt="#5f8a3c", glow="#a0a09a", eye="#ffe08a",
  style="stone", vein=0.0, hp=170, dmg=18, spd=0.20, armor=14, kb=1.0, fire=False, water=False, regen=(0,0), tier=1, hit=("",0,0),
  abil=[A("SLAM",90,12,6,"minecraft:poof"), A("GUARD",400,0,12,"minecraft:crit","resistance",120,1)],
  drops=[("minecraft:cobblestone",6,12),("minecraft:flint",1,3)])
g(key="nature", cat="elemental", family="vegetal", block="minecraft:moss_block", base="#6b4a2a", alt="#3f8f2a", glow="#7dff4a", eye="#8dff3a",
  style="wood", vein=0.15, hp=110, dmg=12, spd=0.24, armor=5, kb=0.5, fire=False, water=False, regen=(40,1.0), tier=1, hit=("poison",60,0),
  abil=[A("ROOTS",140,4,14,"minecraft:composter","slowness",80,6), A("BARRIER",260,0,14,"","",0,0,"ring|minecraft:sweet_berry_bush"), A("HEAL",300,10,0,"minecraft:happy_villager")],
  drops=[("minecraft:bone_meal",3,6),("minecraft:oak_log",2,5)])
g(key="obsidian", cat="special", family="brute", block="minecraft:obsidian", base="#1a1426", alt="#3a2a5a", glow="#8a3cff", eye="#c27bff",
  style="stone", vein=0.25, hp=230, dmg=26, spd=0.16, armor=16, kb=1.0, fire=True, water=False, regen=(0,0), tier=3, hit=("slowness",60,1),
  abil=[A("SLAM",110,18,6,"minecraft:crit"), A("GUARD",350,0,12,"minecraft:witch","resistance",140,1)],
  drops=[("minecraft:obsidian",3,6),("minecraft:crying_obsidian",1,2)])
g(key="prismarine", cat="special", family="crystal", block="minecraft:prismarine", base="#3f9a8a", alt="#7fe0d0", glow="#a8fff0", eye="#bfffee",
  style="crystal", vein=0.1, hp=105, dmg=11, spd=0.25, armor=6, kb=0.5, fire=False, water=True, regen=(0,0), tier=1, hit=("mining_fatigue",100,0),
  abil=[A("BOLT",50,6,18,"minecraft:bubble","slowness",80,1), A("PULSE",150,6,5,"minecraft:bubble_pop","mining_fatigue",100,1)],
  drops=[("minecraft:prismarine_shard",3,6),("minecraft:prismarine_crystals",2,4)])
g(key="sand", cat="special", family="drifter", block="minecraft:sandstone", base="#d8c27a", alt="#b39a52", glow="#f2e2a0", eye="#4a3b12",
  style="sand", vein=0.0, hp=90, dmg=10, spd=0.27, armor=3, kb=0.4, fire=False, water=False, regen=(0,0), tier=1, hit=("blindness",40,0),
  abil=[A("SANDSTORM",150,3,8,"minecraft:cloud","blindness",100,0), A("BOLT",45,5,16,"minecraft:poof","slowness",40,0,"knock")],
  drops=[("minecraft:sand",4,8),("minecraft:dead_bush",1,2)])
g(key="end_stone", cat="special", family="drifter", block="minecraft:end_stone", base="#dcd9a0", alt="#7a3fb0", glow="#c27bff", eye="#e8a0ff",
  style="stone", vein=0.2, hp=100, dmg=12, spd=0.26, armor=5, kb=0.5, fire=False, water=False, regen=(0,0), tier=2, hit=("",0,0),
  abil=[A("TELEPORT",100,0,18,"minecraft:portal"), A("BOLT",50,6,18,"minecraft:end_rod")],
  drops=[("minecraft:end_stone",4,8),("minecraft:chorus_fruit",1,3)])
g(key="moss", cat="special", family="vegetal", block="minecraft:mossy_cobblestone", base="#5c6b4a", alt="#4f9a3a", glow="#9fe05a", eye="#d8ff7a",
  style="stone", vein=0.0, hp=120, dmg=11, spd=0.22, armor=8, kb=0.6, fire=False, water=False, regen=(30,1.0), tier=1, hit=("",0,0),
  abil=[A("HEAL",240,12,0,"minecraft:happy_villager"), A("BARRIER",220,0,14,"","",0,0,"wall|minecraft:moss_block"), A("SPREAD",100,0,4,"minecraft:composter")],
  drops=[("minecraft:moss_block",3,6),("minecraft:vine",2,4)])
# minerales
g(key="coal", cat="mineral", family="horned", block="minecraft:coal_block", base="#1e1e20", alt="#3a3a3e", glow="#ff6a1a", eye="#ff8a2a",
  style="stone", vein=0.3, hp=90, dmg=11, spd=0.24, armor=5, kb=0.5, fire=False, water=False, regen=(0,0), tier=1, hit=("fire",60,0),
  abil=[A("SMOKE",150,3,6,"minecraft:large_smoke","blindness",80,0), A("BOLT",55,5,16,"minecraft:smoke","fire",60,0)],
  drops=[("minecraft:coal",6,12)])
g(key="iron", cat="mineral", family="brute", block="minecraft:iron_block", base="#b8b8b8", alt="#8a8a8a", glow="#e6e6e6", eye="#ffcc66",
  style="metal", vein=0.0, hp=190, dmg=20, spd=0.22, armor=10, kb=1.0, fire=False, water=False, regen=(0,0), tier=1, hit=("",0,0),
  abil=[A("SLAM",100,14,5,"minecraft:crit"), A("GUARD",360,0,12,"minecraft:crit","resistance",120,1)],
  drops=[("minecraft:iron_ingot",4,8)])
g(key="copper", cat="mineral", family="horned", block="minecraft:copper_block", base="#c06a40", alt="#3fb08a", glow="#ffb070", eye="#7dffd8",
  style="metal", vein=0.15, hp=95, dmg=11, spd=0.26, armor=6, kb=0.5, fire=False, water=False, regen=(0,0), tier=1, hit=("",0,0),
  abil=[A("CHAIN",140,5,14,"minecraft:electric_spark"), A("GUARD",380,0,12,"minecraft:electric_spark","resistance",100,1)],
  drops=[("minecraft:copper_ingot",4,8)])
g(key="gold", cat="mineral", family="brute", block="minecraft:gold_block", base="#e8c53a", alt="#fff0a0", glow="#fff6b0", eye="#5a3a00",
  style="metal", vein=0.0, hp=85, dmg=14, spd=0.36, armor=4, kb=0.3, fire=False, water=False, regen=(0,0), tier=2, hit=("",0,0),
  abil=[A("HASTE",200,0,14,"minecraft:crit","speed",100,2), A("BOLT",50,7,14,"minecraft:crit")],
  drops=[("minecraft:gold_ingot",4,8)])
g(key="redstone", cat="mineral", family="horned", block="minecraft:redstone_block", base="#6a0f0f", alt="#b01818", glow="#ff2a2a", eye="#ff6a6a",
  style="metal", vein=0.6, hp=90, dmg=11, spd=0.25, armor=5, kb=0.5, fire=False, water=False, regen=(0,0), tier=1, hit=("",0,0),
  abil=[A("PULSE",120,7,6,"minecraft:angry_villager","weakness",80,0), A("BOLT",50,6,16,"minecraft:crimson_spore","slowness",40,0)],
  drops=[("minecraft:redstone",6,12)])
g(key="lapis", cat="mineral", family="crystal", block="minecraft:lapis_block", base="#1f3fa0", alt="#3d6fe0", glow="#6fa0ff", eye="#bfe0ff",
  style="stone", vein=0.2, hp=90, dmg=10, spd=0.25, armor=4, kb=0.5, fire=False, water=False, regen=(0,0), tier=1, hit=("",0,0),
  abil=[A("BOLT",45,6,18,"minecraft:enchant","weakness",80,0), A("PULSE",160,5,5,"minecraft:enchant","nausea",80,0)],
  drops=[("minecraft:lapis_lazuli",6,12)])
g(key="diamond", cat="mineral", family="brute", block="minecraft:diamond_block", base="#3fd8d0", alt="#a8fff5", glow="#d8fffb", eye="#006a68",
  style="crystal", vein=0.0, hp=210, dmg=24, spd=0.24, armor=16, kb=0.9, fire=False, water=False, regen=(0,0), tier=2, hit=("",0,0),
  abil=[A("SLAM",100,16,5,"minecraft:crit"), A("GUARD",340,0,12,"minecraft:end_rod","resistance",140,1)],
  drops=[("minecraft:diamond",2,4)])
g(key="emerald", cat="mineral", family="crystal", block="minecraft:emerald_block", base="#1ea84a", alt="#7dffa0", glow="#b8ffd0", eye="#003a14",
  style="crystal", vein=0.0, hp=130, dmg=10, spd=0.26, armor=6, kb=0.5, fire=False, water=False, regen=(0,0), tier=1, hit=("",0,0),
  abil=[A("SUPPORT",200,6,8,"minecraft:happy_villager","absorption",200,1), A("BOLT",55,5,16,"minecraft:happy_villager")],
  drops=[("minecraft:emerald",3,6)])
g(key="quartz", cat="mineral", family="crystal", block="minecraft:quartz_block", base="#e8e4da", alt="#fff8f0", glow="#ffffff", eye="#ffd070",
  style="stone", vein=0.1, hp=95, dmg=12, spd=0.26, armor=5, kb=0.5, fire=False, water=False, regen=(0,0), tier=1, hit=("",0,0),
  abil=[A("BOLT",45,7,18,"minecraft:end_rod","blindness",40,0), A("PULSE",150,5,6,"minecraft:end_rod","blindness",60,0)],
  drops=[("minecraft:quartz",4,8)])
g(key="amethyst", cat="mineral", family="crystal", block="minecraft:amethyst_block", base="#8a5cc8", alt="#c9a0ff", glow="#e8d0ff", eye="#ffffff",
  style="crystal", vein=0.0, hp=95, dmg=12, spd=0.25, armor=5, kb=0.5, fire=False, water=False, regen=(0,0), tier=1, hit=("",0,0),
  abil=[A("SOUNDWAVE",130,8,7,"minecraft:sonic_boom"), A("BOLT",50,6,18,"minecraft:witch","slowness",40,0)],
  drops=[("minecraft:amethyst_shard",4,8)])
g(key="netherite", cat="mineral", family="brute", block="minecraft:netherite_block", base="#3b3236", alt="#5a4a50", glow="#ff9a4a", eye="#ff7a1a",
  style="metal", vein=0.2, hp=260, dmg=30, spd=0.20, armor=20, kb=1.0, fire=True, water=False, regen=(0,0), tier=3, hit=("",0,0),
  abil=[A("SLAM",110,20,6,"minecraft:flame"), A("BOLT",70,10,16,"minecraft:flame","fire",100,0)],
  drops=[("minecraft:netherite_scrap",1,2)])

for e in G:
    e["id"] = e["key"] + "_golem"
    es, en = ELEM[e["key"]]
    e["es"], e["en"] = es, en
    if e["key"] == "electric":
        e["name_es"], e["name_en"] = "Gólem Eléctrico", "Electric Golem"
    else:
        e["name_es"], e["name_en"] = "Gólem de " + es, en + " Golem"

assert len(G) == 21
FAMILY_SIZE = {"brute":(1.6,3.0),"crystal":(1.3,2.75),"horned":(1.8,3.0),"vegetal":(1.6,3.25),"drifter":(1.5,3.0)}
