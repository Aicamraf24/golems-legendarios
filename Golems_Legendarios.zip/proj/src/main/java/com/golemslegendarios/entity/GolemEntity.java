package com.golemslegendarios.entity;

import com.golemslegendarios.GolemsConfig;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsTargetGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Entidad unica para los 21 golems; todo lo que cambia entre ellos vive en GolemDef. */
public class GolemEntity extends PathfinderMob {
  private static final EntityDataAccessor<Integer> ABILITY_START =
      SynchedEntityData.defineId(GolemEntity.class, EntityDataSerializers.INT);

  private record Placed(BlockPos pos, Block block, int expire) {}

  private final GolemDef def;
  private final int[] cooldowns;
  private final List<Placed> placed = new ArrayList<>();
  private BlockPos home;

  public GolemEntity(EntityType<? extends GolemEntity> type, Level level) {
    super(type, level);
    this.def = GolemRegistry.defOf(type);
    this.cooldowns = new int[def.abilities().length];
  }

  public static AttributeSupplier.Builder createAttributes(GolemDef d) {
    AttributeSupplier.Builder b = Mob.createMobAttributes()
        .add(Attributes.MAX_HEALTH, d.health() * GolemsConfig.healthMultiplier)
        .add(Attributes.MOVEMENT_SPEED, d.speed())
        .add(Attributes.ATTACK_DAMAGE, d.damage() * GolemsConfig.damageMultiplier)
        .add(Attributes.ARMOR, d.armor())
        .add(Attributes.KNOCKBACK_RESISTANCE, d.knockbackResist())
        .add(Attributes.ATTACK_KNOCKBACK, 1.5)
        .add(Attributes.STEP_HEIGHT, 1.0)
        .add(Attributes.FOLLOW_RANGE, 32.0);
    if (d.waterBreather()) b = b.add(Attributes.WATER_MOVEMENT_EFFICIENCY, 1.0);
    return b;
  }

  public GolemDef def() { return def; }

  /** Tick (tickCount) en que empezo la ultima habilidad; el cliente lo usa para animar. */
  public int abilityStart() { return this.entityData.get(ABILITY_START); }

  public void markAbility() { this.entityData.set(ABILITY_START, this.tickCount); }

  public void trackPlaced(BlockPos pos, Block block, int lifetimeTicks) {
    if (placed.size() < 24) placed.add(new Placed(pos, block, this.tickCount + lifetimeTicks));
  }

  @Override
  protected void defineSynchedData(SynchedEntityData.Builder builder) {
    super.defineSynchedData(builder);
    builder.define(ABILITY_START, -1000);
  }

  @Override
  protected void registerGoals() {
    GolemDef d = GolemRegistry.defOf(this.getType());
    boolean water = d != null && d.waterBreather();
    this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, true));
    this.goalSelector.addGoal(2, new MoveTowardsTargetGoal(this, 0.9, 32.0F));
    this.goalSelector.addGoal(5, water ? new RandomStrollGoal(this, 0.6) : new WaterAvoidingRandomStrollGoal(this, 0.6));
    this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
    this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
    this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Mob.class, 5, false, false,
        (target, level) -> target instanceof Enemy && !(target instanceof Creeper)));
  }

  @Override
  public void aiStep() {
    super.aiStep();
    if (!(this.level() instanceof ServerLevel sl)) return;

    if (home == null) home = this.blockPosition();
    // defensa territorial: sin objetivo y lejos de su zona, vuelve a ella
    if (this.tickCount % 40 == 0 && this.getTarget() == null && this.blockPosition().distSqr(home) > 28 * 28) {
      this.getNavigation().moveTo(home.getX() + 0.5, home.getY(), home.getZ() + 0.5, 0.8);
    }
    for (int i = 0; i < cooldowns.length; i++) if (cooldowns[i] > 0) cooldowns[i]--;

    if (def.regenInterval() > 0 && this.tickCount % def.regenInterval() == 0 && this.getHealth() < this.getMaxHealth()) {
      this.heal(def.regenAmount());
    }

    if (!placed.isEmpty() && this.tickCount % 20 == 0) {
      Iterator<Placed> it = placed.iterator();
      while (it.hasNext()) {
        Placed p = it.next();
        if (this.tickCount >= p.expire()) {
          if (sl.getBlockState(p.pos()).is(p.block())) sl.setBlock(p.pos(), Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
          it.remove();
        }
      }
    }

    LivingEntity target = this.getTarget();
    if (this.tickCount % 5 == 0 && target != null && target.isAlive()) {
      tryAbilities(sl, target, true);
    } else if (this.tickCount % 20 == 0) {
      tryAbilities(sl, target, false);
    }
  }

  private void tryAbilities(ServerLevel sl, LivingEntity target, boolean withTarget) {
    GolemDef.AbilitySpec[] specs = def.abilities();
    for (int i = 0; i < specs.length; i++) {
      GolemDef.AbilitySpec s = specs[i];
      if (cooldowns[i] > 0) continue;
      if (s.kind().needsTarget != withTarget) continue;
      if (!GolemAbilities.canUse(this, s, target)) continue;
      GolemAbilities.use(sl, this, s, target);
      cooldowns[i] = s.cooldown();
      markAbility();
      return; // una habilidad por comprobacion: ligero y sin spam
    }
  }

  @Override
  public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
    boolean hurt = super.hurtServer(level, source, amount);
    if (hurt && amount >= this.getMaxHealth() * 0.15f) {
      // reaccion al dano fuerte: las habilidades se recargan antes (enfurecerse)
      for (int i = 0; i < cooldowns.length; i++) cooldowns[i] = Math.min(cooldowns[i], 10);
    }
    return hurt;
  }

  @Override
  public boolean doHurtTarget(ServerLevel level, Entity target) {
    boolean ok = super.doHurtTarget(level, target);
    if (ok && target instanceof LivingEntity living) {
      GolemAbilities.applyEffect(living, def.hitEffect(), def.hitTicks(), def.hitAmp());
    }
    return ok;
  }

  @Override
  public void remove(Entity.RemovalReason reason) {
    if (reason.shouldDestroy() && this.level() instanceof ServerLevel sl) {
      for (Placed p : placed) {
        if (sl.getBlockState(p.pos()).is(p.block())) sl.setBlock(p.pos(), Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
      }
      placed.clear();
    }
    super.remove(reason);
  }

  @Override public boolean removeWhenFarAway(double distance) { return false; }
  @Override public boolean canBreatheUnderwater() { return def != null && def.waterBreather(); }
  @Override public boolean isPushedByFluid() { return def == null || !def.waterBreather(); }

  // Se reutilizan eventos de sonido que ya existen en el juego (no se anade ningun sonido nuevo).
  @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.IRON_GOLEM_HURT; }
  @Override protected SoundEvent getDeathSound() { return SoundEvents.IRON_GOLEM_DEATH; }
  @Override protected void playStepSound(BlockPos pos, BlockState state) { this.playSound(SoundEvents.IRON_GOLEM_STEP, 1.0F, 1.0F); }
}
