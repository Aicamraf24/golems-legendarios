# -*- coding: utf-8 -*-
"""Anatomia voxel de las 5 familias. Origen: suelo en y=24, unidades en pixeles (16 px = 1 bloque).
Cada caja: (x,y,z,w,h,d,tag). Las extremidades izquierdas se generan espejando las derechas."""
TEX = 128
def B(x,y,z,w,h,d,tag): return (x,y,z,w,h,d,tag)

FAMILIES = {
 "brute": {
  "head": ((0,-14,0), [B(-5,-10,-5,10,10,10,"head"), B(-1,-3,-7,2,4,2,"nose"), B(-5,-10,-6,10,2,1,"plate")]),
  "body": ((0,0,0), [B(-9,-14,-5,18,20,10,"body"), B(-7,-12,-6,14,9,1,"plate"), B(-8,2,-6,16,3,1,"plate")]),
  "right_arm": ((-13,-12,0), [B(-4,-2,-4,8,26,8,"limb"), B(-5,-4,-5,10,5,10,"plate")]),
  "right_leg": ((-5,6,0), [B(-3.5,0,-3.5,7,18,7,"limb"), B(-4,14,-5.5,8,4,9,"plate")]),
  "anim": dict(leg=1.0, arm=0.7, bob=0.0)},
 "crystal": {
  "head": ((0,-10,0), [B(-4,-8,-4,8,8,8,"head"), B(-1,-14,-1,2,6,2,"crystal"), B(-4,-12,-3,2,4,2,"crystal"), B(2,-12,-3,2,4,2,"crystal")]),
  "body": ((0,0,0), [B(-7,-10,-4,14,18,8,"body"), B(-3,-6,-5,6,6,1,"glow"), B(-3,-12,4,3,10,3,"crystal"), B(1,-8,4,2,8,2,"crystal")]),
  "right_arm": ((-10,-8,0), [B(-3,-2,-3,6,22,6,"limb"), B(-4,-6,-4,8,5,8,"plate"), B(-5,-12,-2,3,7,3,"crystal")]),
  "right_leg": ((-3.5,8,0), [B(-3,0,-3,6,16,6,"limb"), B(-3.5,13,-4,7,3,8,"plate")]),
  "anim": dict(leg=1.2, arm=0.9, bob=0.0)},
 "horned": {
  "head": ((0,-14,0), [B(-5,-9,-5,10,9,10,"head"), B(-8,-11,-2,3,5,3,"horn"), B(-9,-15,-2,2,4,2,"horn"), B(5,-11,-2,3,5,3,"horn"), B(7,-15,-2,2,4,2,"horn"), B(-1,-12,-4,2,3,2,"glow")]),
  "body": ((0,0,0), [B(-8,-14,-5,16,20,10,"body"), B(-3,-10,-6,6,6,1,"glow"), B(-6,-18,3,3,6,3,"horn"), B(3,-18,3,3,6,3,"horn"), B(-7,3,-6,14,3,1,"plate")]),
  "right_arm": ((-12,-12,0), [B(-4.5,-2,-4.5,9,24,9,"limb"), B(-5,-5,-5,10,5,10,"plate"), B(-5,-10,-2,4,5,4,"horn")]),
  "right_leg": ((-4.5,6,0), [B(-3.5,0,-3.5,7,18,7,"limb"), B(-4,14,-5,8,4,8,"plate")]),
  "anim": dict(leg=1.0, arm=0.8, bob=0.0)},
 "vegetal": {
  "head": ((0,-18,0), [B(-4,-8,-4,8,8,8,"head"), B(-7,-12,-1,2,6,2,"horn"), B(-8,-16,-1,2,5,2,"horn"), B(5,-12,-1,2,6,2,"horn"), B(6,-16,-1,2,5,2,"horn"), B(-5,-10,-5,10,2,10,"leaf")]),
  "body": ((0,0,0), [B(-8,-18,-5,16,24,10,"body"), B(-9,-14,-6,6,5,2,"leaf"), B(3,-6,-6,6,5,2,"leaf"), B(-4,-20,2,8,4,4,"leaf")]),
  "right_arm": ((-12,-14,0), [B(-3.5,-2,-3.5,7,28,7,"limb"), B(-5,-4,-5,10,6,10,"leaf"), B(-8,6,-1,4,2,2,"horn")]),
  "right_leg": ((-4.5,6,0), [B(-4,0,-4,8,18,8,"limb"), B(-5,12,-5,10,3,10,"leaf")]),
  "anim": dict(leg=0.9, arm=0.6, bob=0.0)},
 "drifter": {
  "head": ((0,-16,0), [B(-4,-8,-4,8,8,8,"head"), B(-5,-4,-5,1,3,10,"plate"), B(4,-4,-5,1,3,10,"plate")]),
  "body": ((0,0,0), [B(-8,-10,-5,16,16,10,"body"), B(-3,-6,-6,6,6,1,"glow"), B(-6,-12,-4,12,2,8,"plate")]),
  "right_arm": ((-13,-6,0), [B(-3,-2,-3,6,8,6,"limb"), B(-4,10,-4,8,9,8,"plate"), B(-2,7,-2,4,2,4,"crystal")]),
  "right_leg": ((-5,12,0), [B(-3,0,-3,6,8,6,"limb"), B(-2,9,-2,4,3,4,"crystal")]),
  "anim": dict(leg=0.5, arm=0.5, bob=1.0)},
}

def mirror_boxes(boxes):
    return [(-(x+w), y, z, w, h, d, t) for (x,y,z,w,h,d,t) in boxes]

def layout(fam):
    """Devuelve dict parte -> dict(pose, boxes[(x,y,z,w,h,d,tag,u,v)], mirror) y lista de rectangulos (para pintar)."""
    f = FAMILIES[fam]
    order = []
    for pname in ("head","body","right_arm","right_leg"):
        pose, boxes = f[pname]
        for b in boxes: order.append((pname, b))
    # empaquetado en estantes
    cu = cv = rowh = 0
    placed = {}
    packed = []
    for pname, b in order:
        x,y,z,w,h,d,tag = b
        tw, th = int(2*d + 2*w), int(d + h)
        if cu + tw > TEX: cu, cv, rowh = 0, cv + rowh, 0
        packed.append((pname, b, cu, cv))
        cu += tw; rowh = max(rowh, th)
    assert cv + rowh <= TEX, (fam, cv+rowh)
    parts = {}
    for pname, b, u, v in packed:
        parts.setdefault(pname, {"pose": f[pname][0], "boxes": [], "mirror": False})["boxes"].append(b + (u, v))
    # izquierda
    for r, l in (("right_arm","left_arm"),("right_leg","left_leg")):
        pose = f[r][0]
        lb = []
        for (x,y,z,w,h,d,tag,u,v) in parts[r]["boxes"]:
            mx = -(x + w)
            lb.append((mx,y,z,w,h,d,tag,u,v))
        parts[l] = {"pose": (-pose[0], pose[1], pose[2]), "boxes": lb, "mirror": True}
    return parts, [(p, b, u, v) for p, b, u, v in packed], f["anim"]
