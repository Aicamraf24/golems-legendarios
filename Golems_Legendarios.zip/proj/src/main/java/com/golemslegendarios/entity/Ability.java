package com.golemslegendarios.entity;

/** Tipos de habilidad. needsTarget=false => se usa sin objetivo (curacion, apoyo, musgo). */
public enum Ability {
  BOLT(true), CHAIN(true), SLAM(true), PULSE(true), SMOKE(true), SANDSTORM(true), SOUNDWAVE(true),
  ROOTS(true), TELEPORT(true), BARRIER(true), GUARD(true), HASTE(true),
  HEAL(false), SUPPORT(false), SPREAD(false);

  public final boolean needsTarget;
  Ability(boolean needsTarget) { this.needsTarget = needsTarget; }
}
