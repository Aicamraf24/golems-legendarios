# -*- coding: utf-8 -*-
"""Validacion ESTATICA (no compila Java ni prueba el juego)."""
import json, os, re, sys, glob
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from golem_table import G
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NS = "golemslegendarios"; A = f"{R}/src/main/resources/assets/{NS}"; D = f"{R}/src/main/resources/data/{NS}"
err = []
def need(p):
    if not os.path.exists(p): err.append("falta " + p)
for f in glob.glob(f"{R}/src/**/*.json", recursive=True):
    try: json.load(open(f, encoding="utf-8"))
    except Exception as e: err.append(f"JSON invalido {f}: {e}")
lang = json.load(open(f"{A}/lang/es_es.json", encoding="utf-8"))
blocks = {}
for e in G:
    k = e["key"]
    need(f"{A}/textures/entity/{e['id']}.png"); need(f"{D}/loot_table/entities/{e['id']}.json")
    if f"entity.{NS}.{e['id']}" not in lang: err.append("lang entidad " + e["id"])
    blocks.setdefault(e["block"], []).append(e["id"])
    names = [f"{k}_{p}" for p in "shard core sword pickaxe helmet chestplate leggings boots".split()] + [e["id"] + "_spawn_egg"]
    for n in names:
        for p in (f"{A}/textures/item/{n}.png", f"{A}/models/item/{n}.json", f"{A}/items/{n}.json"): need(p)
        if f"item.{NS}.{n}" not in lang: err.append("lang item " + n)
    need(f"{A}/equipment/{k}.json"); need(f"{A}/textures/entity/equipment/humanoid/{k}.png"); need(f"{A}/textures/entity/equipment/humanoid_leggings/{k}.png")
    need(f"{D}/tags/item/repair/{k}.json")
    for r in "sword pickaxe helmet chestplate leggings boots".split(): need(f"{D}/recipe/{k}_{r}.json")
    im = Image.open(f"{A}/textures/entity/{e['id']}.png")
    if im.size != (128, 128): err.append("tam textura " + e["id"])
# huevos distintos
eggs = {}
for e in G:
    h = open(f"{A}/textures/item/{e['id']}_spawn_egg.png", "rb").read(); eggs.setdefault(h, []).append(e["id"])
for h, v in eggs.items():
    if len(v) > 1: err.append("huevos identicos: " + str(v))
for b, v in blocks.items():
    if len(v) > 1: err.append(f"bloque de invocacion repetido {b}: {v}")
# Java: llaves/parentesis balanceados y nombres de item registrados == assets
for f in glob.glob(f"{R}/src/**/*.java", recursive=True):
    s = re.sub(r'"(\\.|[^"\\])*"', '""', open(f, encoding="utf-8").read())
    s = re.sub(r"//[^\n]*", "", s); s = re.sub(r"/\*.*?\*/", "", s, flags=re.S)
    for a, b in ("{}", "()", "[]"):
        if s.count(a) != s.count(b): err.append(f"desbalance {a}{b} en {f}")
# sin audio
for ext in ("ogg", "wav", "mp3"):
    if glob.glob(f"{R}/**/*.{ext}", recursive=True): err.append("hay audio ." + ext)
if os.path.exists(f"{R}/src/main/resources/assets/{NS}/sounds.json"): err.append("sounds.json presente")
print("golems:", len(G), "| bloques distintos:", len(blocks), "| errores:", len(err))
for e in err: print(" -", e)
sys.exit(1 if err else 0)
