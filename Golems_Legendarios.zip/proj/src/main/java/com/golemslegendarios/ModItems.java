package com.golemslegendarios;

import com.golemslegendarios.entity.GolemDef;
import com.golemslegendarios.entity.GolemDefs;
import com.golemslegendarios.entity.GolemEntity;
import com.golemslegendarios.entity.GolemRegistry;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAssets;

/** Registro de objetos: huevos, fragmentos, nucleos, espadas, picos y armaduras por golem + pestana creativa. */
public final class ModItems {
  private ModItems() {}

  public static final Map<String, Item> ALL = new LinkedHashMap<>();

  private static Identifier id(String path) { return Identifier.fromNamespaceAndPath(GolemsLegendarios.MOD_ID, path); }

  private static Item register(String name, Item.Properties props, Function<Item.Properties, Item> factory) {
    ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id(name));
    Item item = factory.apply(props.setId(key));
    Registry.register(BuiltInRegistries.ITEM, key, item);
    ALL.put(name, item);
    return item;
  }

  private static ToolMaterial toolMaterial(int tier, TagKey<Item> repair) {
    return switch (tier) {
      case 3 -> new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 2300, 9.5F, 4.5F, 15, repair);
      case 2 -> new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1700, 8.5F, 3.5F, 12, repair);
      default -> new ToolMaterial(BlockTags.INCORRECT_FOR_IRON_TOOL, 600, 7.0F, 2.5F, 14, repair);
    };
  }

  private static ArmorMaterial armorMaterial(int tier, TagKey<Item> repair, String key) {
    Map<ArmorType, Integer> defense = new EnumMap<>(ArmorType.class);
    int[] v = switch (tier) {
      case 3 -> new int[] {3, 8, 6, 3};
      case 2 -> new int[] {3, 8, 6, 3};
      default -> new int[] {2, 6, 5, 2};
    };
    defense.put(ArmorType.HELMET, v[0]);
    defense.put(ArmorType.CHESTPLATE, v[1]);
    defense.put(ArmorType.LEGGINGS, v[2]);
    defense.put(ArmorType.BOOTS, v[3]);
    int durability = tier == 3 ? 40 : tier == 2 ? 35 : 22;
    var sound = tier == 3 ? SoundEvents.ARMOR_EQUIP_NETHERITE : tier == 2 ? SoundEvents.ARMOR_EQUIP_DIAMOND : SoundEvents.ARMOR_EQUIP_IRON;
    float toughness = tier == 3 ? 3.0F : tier == 2 ? 2.0F : 0.5F;
    float knockback = tier == 3 ? 0.1F : 0.0F;
    return new ArmorMaterial(durability, defense, tier == 3 ? 15 : 12, sound, toughness, knockback, repair,
        ResourceKey.create(EquipmentAssets.ROOT_ID, id(key)));
  }

  public static void init() {
    for (GolemDef d : GolemDefs.ALL) {
      String k = d.key();
      TagKey<Item> repair = TagKey.create(Registries.ITEM, id("repair/" + k));
      ToolMaterial tool = toolMaterial(d.tier(), repair);
      ArmorMaterial armor = armorMaterial(d.tier(), repair, k);
      register(k + "_shard", new Item.Properties(), Item::new);
      register(k + "_core", new Item.Properties().rarity(Rarity.RARE), Item::new);
      register(k + "_sword", new Item.Properties().sword(tool, 3.0F, -2.4F), Item::new);
      register(k + "_pickaxe", new Item.Properties().pickaxe(tool, 1.0F, -2.8F), Item::new);
      register(k + "_helmet", new Item.Properties().humanoidArmor(armor, ArmorType.HELMET), Item::new);
      register(k + "_chestplate", new Item.Properties().humanoidArmor(armor, ArmorType.CHESTPLATE), Item::new);
      register(k + "_leggings", new Item.Properties().humanoidArmor(armor, ArmorType.LEGGINGS), Item::new);
      register(k + "_boots", new Item.Properties().humanoidArmor(armor, ArmorType.BOOTS), Item::new);
      EntityType<GolemEntity> type = GolemRegistry.TYPES.get(d.id());
      register(d.id() + "_spawn_egg", new Item.Properties().spawnEgg(type), SpawnEggItem::new);
    }

    CreativeModeTab tab = FabricCreativeModeTab.builder()
        .title(Component.translatable("itemGroup." + GolemsLegendarios.MOD_ID))
        .icon(() -> new ItemStack(ALL.get("fire_golem_spawn_egg")))
        .displayItems((params, output) -> ALL.values().forEach(output::accept))
        .build();
    Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, id("main"), tab);
  }
}
