package com.golemslegendarios.entity;

import com.golemslegendarios.GolemsConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

/**
 * Invocacion por estructura en T (como el golem de hierro): columna de 2 bloques, un bloque a cada lado del
 * segundo y la calabaza tallada encima. Se comprueba al colocar la calabaza (ultimo bloque).
 */
public final class GolemSummoner {
  private GolemSummoner() {}

  /** @return true si se invoco un golem (el llamador cancela entonces la logica vanilla de golems). */
  public static boolean trySummon(ServerLevel level, BlockPos pumpkin) {
    for (GolemDef def : GolemDefs.ALL) {
      Block block = GolemsConfig.blockFor(def);
      if (block == null) continue;
      BlockPos mid = pumpkin.below();
      BlockPos base = mid.below();
      for (Direction side : new Direction[] {Direction.EAST, Direction.SOUTH}) {
        BlockPos a = mid.relative(side);
        BlockPos b = mid.relative(side.getOpposite());
        if (is(level, mid, block) && is(level, base, block) && is(level, a, block) && is(level, b, block)) {
          spawn(level, def, pumpkin, mid, base, a, b);
          return true;
        }
      }
    }
    return false;
  }

  private static boolean is(ServerLevel level, BlockPos p, Block block) {
    return level.getBlockState(p).is(block);
  }

  private static void spawn(ServerLevel level, GolemDef def, BlockPos... positions) {
    for (BlockPos p : positions) level.setBlock(p, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
    BlockPos base = positions[2];
    GolemEntity golem = GolemRegistry.TYPES.get(def.id()).create(level, EntitySpawnReason.TRIGGERED);
    if (golem == null) return;
    golem.snapTo(base.getX() + 0.5, base.getY(), base.getZ() + 0.5, 0.0F, 0.0F);
    golem.setPersistenceRequired();
    level.addFreshEntity(golem);
    level.sendParticles(ParticleTypes.POOF, base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5, 25, 0.5, 1.0, 0.5, 0.02);
  }
}
